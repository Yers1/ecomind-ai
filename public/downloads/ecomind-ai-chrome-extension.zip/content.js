"use strict";
(() => {
  // shared/certifications/certificationRegistry.ts
  var MAX_CERTIFICATION_ADJUSTMENT = 3;
  var CERTIFICATION_REGISTRY = [
    {
      id: "fair-trade-certified",
      officialName: "Fair Trade Certified",
      aliases: ["Fair Trade Certified", "Fairtrade Certified"],
      category: "social-and-labour",
      environmentalScoreEligible: false,
      peopleInformationEligible: true,
      verificationRequirements: ["Exact certification name", "Clear statement applying the certification to this product or its practices"],
      notes: "Shown as People information. It does not add environmental points in the current prototype."
    },
    {
      id: "oeko-tex-standard-100",
      officialName: "OEKO-TEX\xAE STANDARD 100",
      aliases: ["OEKO-TEX\xAE STANDARD 100", "OEKO-TEX STANDARD 100", "STANDARD 100 by OEKO-TEX", "OEKO TEX STANDARD 100"],
      category: "chemical-safety",
      environmentalScoreEligible: false,
      peopleInformationEligible: false,
      verificationRequirements: ["Exact STANDARD 100 name", "Certificate or label number", "Successful OEKO-TEX Label Check"],
      officialUrl: "https://www.oeko-tex.com/en/our-standards/oeko-tex-standard-100",
      notes: "Independent harmful-substance testing evidence. It is useful product-safety information but does not by itself prove lower lifecycle impact, so it adds no Green Score points."
    },
    {
      id: "oeko-tex-made-in-green",
      officialName: "OEKO-TEX\xAE MADE IN GREEN",
      aliases: ["OEKO-TEX\xAE MADE IN GREEN", "OEKO-TEX MADE IN GREEN", "MADE IN GREEN by OEKO-TEX", "OEKO TEX MADE IN GREEN"],
      category: "multi-criteria",
      environmentalScoreEligible: true,
      peopleInformationEligible: true,
      verificationRequirements: ["Exact MADE IN GREEN product label", "Unique product ID or label number", "Successful OEKO-TEX Label Check for this product"],
      officialUrl: "https://www.oeko-tex.com/en/our-standards/oeko-tex-made-in-green",
      notes: "Eligible for a small prototype adjustment only after product-specific verification through the official OEKO-TEX Label Check. Seller wording alone adds zero points."
    }
    // Add the mentor-verified Amazon certification list here after the exact names are supplied.
  ];
  var vagueClaimPattern = /\b(sustainable|eco[- ]?friendly|conscious|responsible|green|natural|better materials|environmentally friendly)\b/i;
  function detectCertificationEvidence(rawText, sourceLabel, evidenceSource, sourceUrl) {
    const text = rawText.replace(/\s+/g, " ").trim();
    const found = [];
    for (const definition of CERTIFICATION_REGISTRY) {
      const alias = definition.aliases.find((candidate) => new RegExp(`\\b${candidate.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\\ /g, "\\s+")}\\b`, "i").test(text));
      if (!alias) continue;
      const claim = text.match(new RegExp(`[^.!?]{0,100}\\b${alias.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\\ /g, "\\s+")}\\b[^.!?]{0,140}`, "i"))?.[0]?.trim() ?? alias;
      const productSpecific = /\b(made with|this product|product is|certified (?:product|materials?|fabric)|carries|labelled|labeled|practices)\b/i.test(claim);
      const certificationIdValue = text.match(/\b(?:[A-Z]{2,6}\d{2,5}\s+\d{5,9}|[A-Z0-9]{2,4}\.[A-Z0-9]{3,5}\.[A-Z0-9]{4,8})\b/i)?.[0] ?? void 0;
      const officialLabelCheck = Boolean(sourceUrl && /^https:\/\/(?:www\.)?oeko-tex\.com\/[^\s]*label-check/i.test(sourceUrl));
      const independentlyVerified = productSpecific && evidenceSource === "manufacturer-link" && officialLabelCheck && Boolean(certificationIdValue);
      const status = independentlyVerified ? "verified" : productSpecific ? "seller-claim" : "partially-verified";
      found.push({ certificationId: definition.id, displayedName: definition.officialName, rawClaim: claim, status, evidenceSource, sourceLabel, ...sourceUrl ? { sourceUrl } : {}, ...certificationIdValue ? { certificationIdValue } : {}, confidence: independentlyVerified ? "high" : productSpecific ? "medium" : "low", affectsEnvironmentalScore: independentlyVerified && definition.environmentalScoreEligible, affectsPeopleInformation: definition.peopleInformationEligible });
    }
    const genericCertified = text.match(/[^.!?]{0,100}\b(?:certified materials?|certified recycled fabric|regenerative organic certified|certification|climate pledge friendly)\b[^.!?]{0,140}/gi) ?? [];
    const materialClaims = text.match(/\bmade with\s+(?:regenerative\s+)?(?:organic|recycled)\s+(?:cotton|polyester|fabric|materials?)\b/gi) ?? [];
    const claims = [...genericCertified.filter((claim) => !found.some((item) => item.rawClaim === claim.trim())), ...materialClaims, ...vagueClaimPattern.test(text) ? text.match(/[^.!?]{0,80}\b(?:sustainable|eco[- ]?friendly|conscious|responsible|green|natural|better materials|environmentally friendly)\b[^.!?]{0,100}/gi) ?? [] : []].map((claim) => claim.trim());
    return { certifications: deduplicateCertificationEvidence(found), sustainabilityClaims: [...new Set(claims)] };
  }
  function deduplicateCertificationEvidence(items) {
    const seen = /* @__PURE__ */ new Set();
    return items.filter((item) => {
      const key = item.certificationId ?? `${item.displayedName.toLowerCase()}:${item.rawClaim.toLowerCase()}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function certificationAdjustment(items) {
    const eligible = deduplicateCertificationEvidence(items).filter((item) => item.status === "verified" && item.affectsEnvironmentalScore && item.certificationId);
    return Math.min(MAX_CERTIFICATION_ADJUSTMENT, eligible.length === 0 ? 0 : eligible.length === 1 ? 2 : 3);
  }

  // shared/ecomind.ts
  var SCORE_WEIGHTS = {
    materials: 0.35,
    carbon: 0.25,
    recycled: 0.2,
    durability: 0.1,
    fulfilmentPackaging: 0.05,
    manufacturerPackaging: 0.05
  };
  function migrateLegacyPackaging(value) {
    if (value && typeof value === "object" && ("fulfilment" in value || "manufacturer" in value)) return value;
    if (typeof value !== "string" || !value.trim()) return { fulfilment: null, manufacturer: null };
    const description = value.trim();
    const evidence = { description, material: null, recycledContentPercentage: null, reducedPackagingOption: null, sourceType: "ecomind-estimate", sourceLabel: "Legacy packaging evidence \u2014 review required", confidence: "low" };
    if (/polybag|branded (?:product )?box|plastic wrap|original packaging|individual packaging/i.test(description)) return { fulfilment: null, manufacturer: evidence };
    if (/delivery box|shipping box|mailer|delivery bag|fulfilment|fulfillment/i.test(description)) return { fulfilment: evidence, manufacturer: null };
    return { fulfilment: null, manufacturer: null, legacy: evidence };
  }
  function packagingEvidenceLabel(evidence) {
    if (!evidence) return "Not disclosed";
    const source = evidence.sourceType === "retailer-policy" ? "Estimated from retailer policy" : evidence.sourceLabel;
    return `${evidence.description ?? evidence.material ?? "Packaging disclosed"} \xB7 ${source} \xB7 ${evidence.confidence} confidence`;
  }
  var sampleListing = (note) => ({ label: "Sample product listing", type: "listing", note });
  var demoEstimate = (note) => ({ label: "EcoMind demo estimate", type: "ecomind-estimate", note });
  var prototypeAssumption = (note) => ({ label: "Prototype assumption", type: "ecomind-estimate", note });
  var performanceListing = sampleListing("Fictional Threadly listing created for the controlled demo.");
  var performanceEstimate = demoEstimate("Illustrative value created locally for the prototype; not lifecycle-assessment data.");
  var cottonListing = sampleListing("Fictional Threadly listing with deliberately incomplete disclosure.");
  var cottonEstimate = demoEstimate("Illustrative range midpoint created locally for the prototype.");
  var renewListing = sampleListing("Fictional Threadly listing created for the controlled demo.");
  var renewSupplier = demoEstimate("Fictional supplier-style statement used only to demonstrate source labelling.");
  var factorAssumption = prototypeAssumption("Fixed sample factor used by the published prototype formula.");
  var PRODUCT_RECORDS = [
    {
      id: "polyester-everyday-tee",
      productName: "Northline Everyday Performance Tee",
      shortName: "Performance Tee",
      category: "Clothing",
      price: 14.99,
      currency: "GBP",
      rating: 4.4,
      reviewCount: 318,
      color: "Charcoal",
      description: "A lightweight everyday T-shirt with quick-dry fabric and a relaxed unisex fit.",
      listingText: "Shell: 100% polyester. Quick-dry jersey. Packed in an individual protective polybag.",
      materials: [{ material: "Polyester", percentage: 100 }],
      recycledContentPercentage: 0,
      estimatedCarbonKg: 5.2,
      carbonValueType: "estimated",
      packaging: { fulfilment: null, manufacturer: { description: "Individual protective polybag", material: "Plastic", recycledContentPercentage: null, reducedPackagingOption: null, sourceType: "product-page", sourceLabel: "Threadly sample product listing", confidence: "high" } },
      durabilityRating: 62,
      circularityRating: 45,
      certifications: [],
      sustainabilityClaims: [],
      sources: [performanceListing, performanceEstimate, factorAssumption],
      factorSources: { materials: [performanceListing, factorAssumption], carbon: [performanceEstimate], recycled: [performanceListing], durability: [factorAssumption], manufacturerPackaging: [performanceListing, factorAssumption] },
      missingFields: ["Manufacturing location", "Supplier lifecycle assessment", "End-of-life guidance"],
      confidenceLevel: "Medium",
      alternativeProductId: "renew-loop-tee",
      peopleInformation: "Labour and supplier audit information is not disclosed in this demo listing.",
      mainAdvantage: "Lowest upfront price and quick-dry fabric.",
      tradeOff: "Virgin synthetic fibre and plastic packaging increase estimated impact."
    },
    {
      id: "cotton-classic-tee",
      productName: "Willow & Thread Classic Cotton Tee",
      shortName: "Cotton Tee",
      category: "Clothing",
      price: 18.5,
      currency: "GBP",
      rating: 4.6,
      reviewCount: 204,
      color: "Natural White",
      description: "A soft midweight cotton T-shirt with a classic fit and reinforced neckline.",
      listingText: "100% cotton jersey. Paper swing tag. Other packaging, recycled content and fibre origin are not disclosed.",
      materials: [{ material: "Cotton", percentage: 100 }],
      recycledContentPercentage: null,
      estimatedCarbonKg: 4.1,
      carbonValueType: "estimated",
      packaging: { fulfilment: null, manufacturer: null },
      durabilityRating: 65,
      circularityRating: 55,
      certifications: [],
      sustainabilityClaims: [],
      sources: [cottonListing, cottonEstimate, factorAssumption],
      factorSources: { materials: [cottonListing, factorAssumption], carbon: [cottonEstimate], durability: [factorAssumption] },
      missingFields: ["Recycled content", "Fulfilment packaging", "Manufacturer packaging", "Cotton origin", "Supplier lifecycle assessment"],
      confidenceLevel: "Low",
      alternativeProductId: "renew-loop-tee",
      peopleInformation: "Labour conditions and responsible sourcing information are not disclosed.",
      mainAdvantage: "Familiar natural fibre and a midweight construction.",
      tradeOff: "Several important product details are missing, so the result is provisional."
    },
    {
      id: "renew-loop-tee",
      productName: "Mosswell Renew Loop Tee",
      shortName: "Renew Loop Tee",
      category: "Clothing",
      price: 21,
      currency: "GBP",
      rating: 4.7,
      reviewCount: 126,
      color: "Forest Green",
      description: "A durable jersey T-shirt made with recycled cotton and lower-impact lyocell.",
      listingText: "60% recycled cotton, 40% lyocell. Individual recycled-card product sleeve. Recycled-paper delivery mailer. Repair patch included.",
      materials: [{ material: "Recycled cotton", percentage: 60 }, { material: "Lyocell", percentage: 40 }],
      recycledContentPercentage: 60,
      estimatedCarbonKg: 1.9,
      carbonValueType: "listed",
      packaging: { fulfilment: { description: "Recycled-paper delivery mailer", material: "Recycled paper", recycledContentPercentage: null, reducedPackagingOption: true, sourceType: "product-page", sourceLabel: "Threadly sample delivery information", confidence: "high" }, manufacturer: { description: "Individual recycled-card product sleeve", material: "Recycled cardboard", recycledContentPercentage: null, reducedPackagingOption: true, sourceType: "product-page", sourceLabel: "Threadly sample product listing", confidence: "high" } },
      durabilityRating: 84,
      circularityRating: 86,
      certifications: [],
      sustainabilityClaims: ["Demo material claim"],
      sources: [renewListing, renewSupplier, factorAssumption],
      factorSources: { materials: [renewListing, factorAssumption], carbon: [renewSupplier], recycled: [renewListing], durability: [factorAssumption], fulfilmentPackaging: [renewListing, factorAssumption], manufacturerPackaging: [renewListing, factorAssumption] },
      missingFields: ["Country-specific end-of-life route"],
      confidenceLevel: "High",
      alternativeProductId: null,
      peopleInformation: "A fictional supplier code of conduct is listed. It is not independently verified in the prototype.",
      mainAdvantage: "High recycled content, lower demo carbon estimate and minimal packaging.",
      tradeOff: "Costs a little more than the conventional options."
    }
  ];
  var materialFactors = { Polyester: 28, Cotton: 48, "Recycled cotton": 80, Lyocell: 88 };
  var clamp = (value) => Math.min(100, Math.max(0, value));
  function calculateConfidence(product) {
    const missingScoreFactors = [!product.materials.length, product.estimatedCarbonKg === null, product.recycledContentPercentage === null, product.packaging.fulfilment === null, product.packaging.manufacturer === null].filter(Boolean).length;
    if (missingScoreFactors >= 2 || product.missingFields.length >= 4) return "Low";
    if (missingScoreFactors === 1 || product.carbonValueType === "estimated" || product.missingFields.length >= 2) return "Medium";
    return "High";
  }
  function calculateGreenScore(product) {
    const materialScore = product.materials.length ? product.materials.reduce((total, item) => total + (materialFactors[item.material] ?? 40) * (item.percentage / 100), 0) : null;
    const carbonScore = product.estimatedCarbonKg === null ? null : clamp(100 - product.estimatedCarbonKg * 12);
    const recycledScore = product.recycledContentPercentage;
    const durabilityScore = Number.isFinite(product.durabilityRating) && Number.isFinite(product.circularityRating) ? (product.durabilityRating + product.circularityRating) / 2 : null;
    const packageScore = (evidence) => {
      if (!evidence) return null;
      const text = `${evidence.description ?? ""} ${evidence.material ?? ""}`.toLowerCase();
      if (/plastic|polybag/.test(text)) return 25;
      if (evidence.reducedPackagingOption === true) return 90;
      if (/recycled card|recycled paper/.test(text)) return 85;
      if (/paper|card/.test(text)) return 65;
      return evidence.material || evidence.description ? 50 : null;
    };
    const fulfilmentPackagingScore = packageScore(product.packaging.fulfilment);
    const manufacturerPackagingScore = packageScore(product.packaging.manufacturer);
    const scores = { materials: materialScore, carbon: carbonScore, recycled: recycledScore, durability: durabilityScore, fulfilmentPackaging: fulfilmentPackagingScore, manufacturerPackaging: manufacturerPackagingScore };
    const details = {
      materials: product.materials.length ? product.materials.map((item) => `${item.percentage}% ${item.material.toLowerCase()}`).join(", ") : "Not disclosed",
      carbon: product.estimatedCarbonKg === null ? "Not disclosed" : `${product.estimatedCarbonKg.toFixed(1)} kg CO2e, ${product.carbonValueType === "listed" ? "sample listing claim" : "EcoMind demo estimate"}`,
      recycled: product.recycledContentPercentage === null ? "Not disclosed \u2014 unknown is not treated as 0%" : `${product.recycledContentPercentage}% disclosed recycled content`,
      durability: durabilityScore === null ? "Not disclosed" : `Prototype durability ${product.durabilityRating}/100, circularity ${product.circularityRating}/100`,
      fulfilmentPackaging: product.packaging.fulfilment?.description ?? "Not disclosed \u2014 retailer or delivery packaging remains unknown",
      manufacturerPackaging: product.packaging.manufacturer?.description ?? "Not disclosed \u2014 supplier packaging remains unknown"
    };
    const labels = { materials: "Material impact", carbon: "Estimated carbon", recycled: "Recycled content", durability: "Durability and circularity", fulfilmentPackaging: "Fulfilment packaging", manufacturerPackaging: "Manufacturer packaging" };
    const breakdown = Object.keys(SCORE_WEIGHTS).map((key) => ({
      key,
      label: labels[key],
      score: scores[key],
      weight: SCORE_WEIGHTS[key],
      weightedPoints: scores[key] === null ? null : scores[key] * SCORE_WEIGHTS[key],
      detail: details[key],
      sources: product.factorSources[key] ?? []
    }));
    const known = breakdown.filter((item) => item.score !== null);
    const knownWeight = known.reduce((total, item) => total + item.weight, 0);
    const knownPoints = known.reduce((total, item) => total + (item.weightedPoints ?? 0), 0);
    const provisional = knownWeight < 0.999;
    const baseScore = Math.round(knownWeight > 0 ? knownPoints / knownWeight : 0);
    const adjustment = certificationAdjustment(product.certifications);
    const score = Math.min(100, baseScore + adjustment);
    const range = provisional ? { min: Math.min(100, Math.floor(knownPoints) + adjustment), max: Math.min(100, Math.ceil(knownPoints + (1 - knownWeight) * 100) + adjustment) } : null;
    const grade = score >= 80 ? "A" : score >= 65 ? "B" : score >= 45 ? "C" : score >= 25 ? "D" : "E";
    const status = provisional ? "Provisional estimate" : grade === "A" ? "Lower impact" : grade === "B" ? "Good choice" : grade === "C" ? "Mixed impact" : "Higher impact";
    const strongest = [...known].sort((a, b) => (b.score ?? 0) - (a.score ?? 0))[0];
    const weakest = [...known].sort((a, b) => (a.score ?? 0) - (b.score ?? 0))[0];
    const explanation = provisional ? `Available evidence suggests about ${score}/100, but undisclosed factors could move the result into the ${range?.min}\u2013${range?.max} range.` : `${strongest.label} helps this score, while ${weakest.label.toLowerCase()} is the main area for improvement.`;
    return { score, grade, status, explanation, breakdown, provisional, range, knownWeight, baseScore, certificationAdjustment: adjustment };
  }

  // shared/parsers/materialExtraction.ts
  var MATERIAL_ALIASES = [
    { pattern: "regenerative\\s+organic\\s+cotton", normalised: "Regenerative Organic Cotton" },
    { pattern: "repreve(?:\xAE)?(?:\\s+recycled)?\\s+polyester", normalised: "Recycled polyester" },
    { pattern: "recycled\\s+polyester|rpet", normalised: "Recycled polyester" },
    { pattern: "recycled\\s+cotton", normalised: "Recycled cotton" },
    { pattern: "organic\\s+cotton", normalised: "Organic cotton" },
    { pattern: "recycled\\s+nylon", normalised: "Recycled nylon" },
    { pattern: "recycled\\s+wool", normalised: "Recycled wool" },
    { pattern: "recycled\\s+fib(?:re|er)s?", normalised: "Recycled fibres" },
    { pattern: "polyester", normalised: "Polyester" },
    { pattern: "cotton", normalised: "Cotton" },
    { pattern: "nylon|polyamide", normalised: "Nylon" },
    { pattern: "elastane|spandex", normalised: "Elastane" },
    { pattern: "linen|flax", normalised: "Linen" },
    { pattern: "hemp", normalised: "Hemp" },
    { pattern: "wool", normalised: "Wool" },
    { pattern: "rayon|viscose", normalised: "Viscose family" },
    { pattern: "modal|micromodal", normalised: "Modal" },
    { pattern: "lyocell|tencel(?:\u2122)?", normalised: "Lyocell" },
    { pattern: "acrylic", normalised: "Acrylic" },
    { pattern: "silk", normalised: "Silk" },
    { pattern: "leather", normalised: "Leather" }
  ];
  var MATERIAL_PATTERN = MATERIAL_ALIASES.map((item) => item.pattern).join("|");
  function normaliseMaterial(raw) {
    const lower = raw.toLowerCase();
    return MATERIAL_ALIASES.find((item) => new RegExp(`^(?:${item.pattern})$`, "i").test(lower))?.normalised ?? raw.trim();
  }
  function pushUnique(materials, material) {
    const existing = materials.find((item) => item.name === material.name && item.percentage === material.percentage);
    if (!existing) materials.push(material);
  }
  function extractMaterials(text) {
    const source = text.replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
    if (!source || /(?:composition|material)(?:\s+is)?\s+not\s+disclosed/i.test(source)) return { materials: [], uncertain: false, rejected: [] };
    const materials = [];
    const rejected = [];
    const percentFirst = new RegExp(`(\\d{1,3}(?:\\.\\d+)?)\\s*%\\s*(${MATERIAL_PATTERN})`, "gi");
    const materialFirst = new RegExp(`(${MATERIAL_PATTERN})\\s*(\\d{1,3}(?:\\.\\d+)?)\\s*%`, "gi");
    const ranged = new RegExp(`(\\d{1,3})\\s*[-\u2013]\\s*(\\d{1,3})\\s*%\\s*(${MATERIAL_PATTERN})`, "gi");
    for (const match of source.matchAll(ranged)) {
      pushUnique(materials, { name: normaliseMaterial(match[3]), percentage: null, evidence: match[0], originalName: match[3] });
      rejected.push(`Percentage range kept uncertain: ${match[0]}`);
    }
    const withoutRanges = source.replace(ranged, " ");
    for (const match of withoutRanges.matchAll(percentFirst)) {
      const percentage = Number(match[1]);
      if (percentage > 100) {
        rejected.push(`Percentage above 100 rejected: ${match[0]}`);
        continue;
      }
      pushUnique(materials, { name: normaliseMaterial(match[2]), percentage, evidence: match[0], originalName: match[2] });
    }
    for (const match of withoutRanges.matchAll(materialFirst)) {
      const percentage = Number(match[2]);
      if (percentage > 100) {
        rejected.push(`Percentage above 100 rejected: ${match[0]}`);
        continue;
      }
      pushUnique(materials, { name: normaliseMaterial(match[1]), percentage, evidence: match[0], originalName: match[1] });
    }
    if (!materials.length) {
      const noPercent = new RegExp(`\\b(${MATERIAL_PATTERN})\\b`, "gi");
      for (const match of source.matchAll(noPercent)) pushUnique(materials, { name: normaliseMaterial(match[1]), percentage: null, evidence: match[0], originalName: match[1] });
    }
    const percentages = materials.map((item) => item.percentage).filter((value) => value !== null);
    const total = percentages.reduce((sum, value) => sum + value, 0);
    const layered = /\b(shell|outer|lining|body|trim)\b/i.test(source);
    const variationDependent = /\b(?:solids?|heathers?|others?|colou?rs?|styles?)\s*:/i.test(source);
    if (variationDependent) rejected.push("Multiple variation-specific compositions detected; confirm the selected colour or style before scoring.");
    const uncertain = rejected.length > 0 || variationDependent || percentages.length > 0 && !layered && (total < 95 || total > 105);
    if (percentages.length > 0 && !layered && (total < 95 || total > 105)) rejected.push(`Composition totals ${total}%, outside the accepted 95\u2013105% range.`);
    return { materials, uncertain, rejected };
  }
  function extractRecycledPercentage(text, materials) {
    const explicit = text.match(/(?:at\s+least\s+)?(\d{1,3}(?:\.\d+)?)\s*%\s+(?:post-consumer\s+)?recycled(?:\s+content|\s+(?:cotton|polyester|nylon|wool|fib(?:re|er)s?))?/i);
    if (explicit) return Math.min(100, Number(explicit[1]));
    const recycled = materials.filter((item) => /^Recycled /i.test(item.name) && item.percentage !== null);
    if (!recycled.length) return null;
    return Math.min(100, recycled.reduce((sum, item) => sum + (item.percentage ?? 0), 0));
  }

  // shared/parsers/parserUtils.ts
  var CLOTHING_TERMS = /\b(t-?shirt|shirt|tee|top|dress|skirt|trouser|pants|jeans|jacket|coat|hoodie|sweater|jumper|cardigan|shorts|sock|underwear|bra|apparel|clothing|fashion|garment|shoe|sneaker|trainer|scarf|hat|cap|glove|flannel|overshirt)\b/i;
  var UNSUPPORTED_TERMS = /\b(laptop|phone|smartphone|tablet|television|camera|headphone|speaker|cosmetic|lipstick|shampoo|food|supplement|furniture|sofa|mattress|appliance|toy)\b/i;
  function cleanText(value) {
    return value?.replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim() || null;
  }
  function selectorText(document2, selectors, matched) {
    for (const selector of selectors) {
      const value = cleanText(document2.querySelector(selector)?.textContent);
      if (value) {
        matched.push(selector);
        return value;
      }
    }
    return null;
  }
  function selectorAttribute(document2, selectors, attribute, matched) {
    for (const selector of selectors) {
      const value = cleanText(document2.querySelector(selector)?.getAttribute(attribute));
      if (value) {
        matched.push(`${selector}[${attribute}]`);
        return value;
      }
    }
    return null;
  }
  function parsePriceText(value) {
    if (!value) return { price: null, currency: null };
    const currency = /HK\$/i.test(value) ? "HKD" : /KZT/i.test(value) ? "KZT" : /₹|\bRs\.?/i.test(value) ? "INR" : /£/.test(value) ? "GBP" : /€/.test(value) ? "EUR" : /\$/.test(value) ? "USD" : null;
    const number = value.match(/\d[\d.,]*/)?.[0];
    if (!number) return { price: null, currency };
    const lastComma = number.lastIndexOf(",");
    const lastDot = number.lastIndexOf(".");
    let normalised = number;
    if (lastComma > lastDot && number.length - lastComma <= 3) normalised = number.replace(/\./g, "").replace(",", ".");
    else normalised = number.replace(/,/g, "");
    const price = Number(normalised);
    return { price: Number.isFinite(price) ? price : null, currency };
  }
  function parseWeightGrams(text) {
    const grams = text.match(/(?:item\s+|net\s+)?weight\s*:?\s*(\d+(?:\.\d+)?)\s*(g|kg|oz|lb)\b/i);
    if (!grams) return null;
    const value = Number(grams[1]);
    return grams[2].toLowerCase() === "kg" ? value * 1e3 : grams[2].toLowerCase() === "oz" ? value * 28.3495 : grams[2].toLowerCase() === "lb" ? value * 453.592 : value;
  }
  function makeEvidence(field, value, sourceType, sourceLabel, confidence, selector) {
    return { field, value, sourceType, sourceLabel, confidence, ...selector ? { selector } : {} };
  }
  function emptyProduct(url, retailer, parserUsed) {
    return { url, retailer, productId: null, title: null, brand: null, category: null, price: null, currency: null, imageUrl: null, description: null, featureText: [], materials: [], materialCompositionUncertain: false, recycledContentPercentage: null, certifications: [], sustainabilityClaims: [], weightGrams: null, packaging: { fulfilment: null, manufacturer: null }, countryOfOrigin: null, careInstructions: null, shipperSeller: null, evidence: [], missingFields: [], parserUsed, isProduct: false, isClothing: false };
  }
  function evidenceText(product) {
    return [product.title, product.category, product.description, ...product.featureText, ...product.materials.map((item) => `${item.percentage ?? ""}% ${item.name}`)].filter(Boolean).join(" ");
  }
  function finaliseProduct(product) {
    const text = evidenceText(product);
    product.isProduct = Boolean(product.title && (product.price !== null || product.productId || product.imageUrl || product.description));
    product.isClothing = product.materials.length > 0 || CLOTHING_TERMS.test(text) && !UNSUPPORTED_TERMS.test(text);
    const required = [["Product title", product.title], ["Price", product.price], ["Material composition", product.materials.length ? product.materials : null], ["Recycled content", product.recycledContentPercentage], ["Fulfilment packaging", product.packaging.fulfilment], ["Manufacturer packaging", product.packaging.manufacturer], ["Country of origin", product.countryOfOrigin], ["Care instructions", product.careInstructions], ["Product weight", product.weightGrams]];
    product.missingFields = required.filter(([, value]) => value === null || value === void 0).map(([label]) => label);
    return product;
  }
  function buildDiagnostics(product, matchedSelectors, jsonLdProductFound, rawFields, rejectedFields = []) {
    return { url: product.url, parserSelected: product.parserUsed, matchedSelectors: [...new Set(matchedSelectors)], jsonLdProductFound, rawFields, normalisedFields: { title: product.title, brand: product.brand, category: product.category, price: product.price, currency: product.currency, materials: product.materials, recycledContentPercentage: product.recycledContentPercentage, certifications: product.certifications, sustainabilityClaims: product.sustainabilityClaims, weightGrams: product.weightGrams, packaging: product.packaging, countryOfOrigin: product.countryOfOrigin, careInstructions: product.careInstructions, shipperSeller: product.shipperSeller }, rejectedFields, missingFields: product.missingFields };
  }
  function packagingEvidence(description, sourceLabel, confidence) {
    const material = description.match(/recycled[- ]?(?:cardboard|card|paper)|cardboard|paper|plastic/i)?.[0] ?? null;
    const recycled = description.match(/(\d{1,3})%\s+recycled/i)?.[1];
    return { description, material, recycledContentPercentage: recycled ? Math.min(100, Number(recycled)) : null, reducedPackagingOption: /reduced packaging|ships? in product packaging|plastic[- ]free|minimal packaging/i.test(description) ? true : null, sourceType: "product-page", sourceLabel, confidence };
  }
  function applyPackagingEvidence(product, text, sourceLabel, selector) {
    const fulfilment = text.match(/(?:delivery|shipping|fulfilment|fulfillment)[^.!?\n]{0,90}(?:box|mailer|bag|packaging|filling|tape)|(?:ships? in product packaging|ships? plastic[- ]free|reduced packaging|recyclable delivery packaging)[^.!?\n]{0,90}/i)?.[0]?.trim();
    const manufacturer = text.match(/(?:individual (?:protective )?polybag|manufacturer(?:'s)? packaging|original packaging|branded (?:product )?box|plastic wrapping|product sleeve|protective product packaging)[^.!?\n]{0,90}/i)?.[0]?.trim();
    if (fulfilment) {
      product.packaging.fulfilment = packagingEvidence(fulfilment, sourceLabel, "high");
      product.evidence.push(makeEvidence("fulfilmentPackaging", fulfilment, "visible-page", sourceLabel, "high", selector));
    }
    if (manufacturer) {
      product.packaging.manufacturer = packagingEvidence(manufacturer, sourceLabel, "high");
      product.evidence.push(makeEvidence("manufacturerPackaging", manufacturer, "visible-page", sourceLabel, "high", selector));
    }
  }
  function applyTextEvidence(product, text, sourceType, sourceLabel, selector) {
    const extraction = extractMaterials(text);
    if (extraction.materials.length) {
      product.materials = extraction.materials;
      product.materialCompositionUncertain = extraction.uncertain;
      product.evidence.push(makeEvidence("materials", text, sourceType, sourceLabel, extraction.uncertain ? "medium" : "high", selector));
    }
    product.recycledContentPercentage = extractRecycledPercentage(text, product.materials);
    if (product.recycledContentPercentage !== null) product.evidence.push(makeEvidence("recycledContentPercentage", product.recycledContentPercentage, sourceType, sourceLabel, "high", selector));
    applyPackagingEvidence(product, text, sourceLabel, selector);
    const certificationEvidence = detectCertificationEvidence(text, sourceLabel, sourceType === "json-ld" ? "structured-data" : /sustainab/i.test(sourceLabel) ? "sustainability-section" : "product-details");
    product.certifications = deduplicateCertificationEvidence([...product.certifications, ...certificationEvidence.certifications]);
    product.sustainabilityClaims = [.../* @__PURE__ */ new Set([...product.sustainabilityClaims, ...certificationEvidence.sustainabilityClaims])];
    return extraction.rejected;
  }
  function result(product, matched, jsonLd, raw, rejected = []) {
    finaliseProduct(product);
    return { product, diagnostics: buildDiagnostics(product, matched, jsonLd, raw, rejected) };
  }

  // shared/parsers/amazonParser.ts
  var AMAZON_HOSTS = /(^|\.)(amazon\.com|amazon\.co\.uk)$/i;
  var AMAZON_SELECTORS = {
    title: ["#productTitle", "#title"],
    image: ["#landingImage", "#imgBlkFront"],
    price: ["#corePrice_feature_div .a-price .a-offscreen", "#corePriceDisplay_desktop_feature_div .a-price .a-offscreen", ".a-price .a-offscreen", "#priceblock_ourprice", "#priceblock_dealprice"],
    features: ["#feature-bullets", "#productFactsDesktopExpander", "#productFactsMobileExpander"],
    description: ["#productDescription", "#aplus"],
    details: ["#productFactsDesktopExpander", "#detailBullets_feature_div", "#detailBulletsWrapper_feature_div", "#productDetails_detailBullets_sections1", "#productDetails_techSpec_section_1", "#productOverview_feature_div"]
  };
  function labelledValue(text, labels) {
    for (const label of labels) {
      const pattern = new RegExp(`${label.replace(/\s+/g, "\\s+")}\\s*:?\\s*([^\\n]{2,250})`, "i");
      const match = text.match(pattern);
      if (match) return cleanText(match[1]);
    }
    return null;
  }
  var amazonParser = {
    id: "amazon",
    canParse(_document, url) {
      return AMAZON_HOSTS.test(new URL(url).hostname) && /\/(?:dp|gp\/product)\//i.test(new URL(url).pathname);
    },
    parse(document2, url) {
      const matched = [];
      const product = emptyProduct(url, new URL(url).hostname.endsWith(".co.uk") ? "Amazon UK" : "Amazon", "amazon");
      product.title = selectorText(document2, [...AMAZON_SELECTORS.title], matched);
      product.imageUrl = selectorAttribute(document2, [...AMAZON_SELECTORS.image], "src", matched) ?? selectorAttribute(document2, [...AMAZON_SELECTORS.image], "data-old-hires", matched);
      const priceText = selectorText(document2, [...AMAZON_SELECTORS.price], matched);
      const price = parsePriceText(priceText);
      product.price = price.price;
      product.currency = price.currency;
      product.productId = document2.querySelector("input#ASIN")?.value || new URL(url).pathname.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/i)?.[1] || null;
      product.brand = selectorText(document2, ["#bylineInfo", "#brand"], matched)?.replace(/^Visit the | Store$/gi, "") ?? null;
      product.category = selectorText(document2, ["#wayfinding-breadcrumbs_feature_div", "#nav-subnav"], matched);
      product.description = selectorText(document2, [...AMAZON_SELECTORS.description], matched);
      const featureBlocks = AMAZON_SELECTORS.features.map((selector) => {
        const value = cleanText(document2.querySelector(selector)?.textContent);
        if (value) matched.push(selector);
        return value;
      }).filter((value) => Boolean(value));
      const detailBlocks = AMAZON_SELECTORS.details.map((selector) => {
        const value = cleanText(document2.querySelector(selector)?.textContent);
        if (value) matched.push(selector);
        return value;
      }).filter((value) => Boolean(value));
      product.featureText = [.../* @__PURE__ */ new Set([...featureBlocks, ...detailBlocks])];
      const evidenceText2 = [product.description, ...product.featureText].filter(Boolean).join(" \n ");
      const rejected = applyTextEvidence(product, evidenceText2, "amazon-selector", "Amazon product details", matched.find((item) => item.includes("productFacts")) ?? matched.find((item) => item.includes("feature-bullets")));
      product.weightGrams = parseWeightGrams(evidenceText2);
      product.countryOfOrigin = labelledValue(evidenceText2, ["Country of origin", "Origin"]);
      product.careInstructions = labelledValue(evidenceText2, ["Care instructions", "Care"]);
      product.shipperSeller = labelledValue(evidenceText2, ["Shipper / seller", "Ships from and sold by"]);
      const genericPackaging = labelledValue(evidenceText2, ["Packaging", "Package type"]);
      if (genericPackaging && !product.packaging.fulfilment && !product.packaging.manufacturer) rejected.push("Packaging wording was ambiguous and was not duplicated across both packaging stages.");
      if (product.title) product.evidence.push(makeEvidence("title", product.title, "amazon-selector", "Amazon product title", "high", matched.find((item) => AMAZON_SELECTORS.title.includes(item))));
      if (product.price !== null) product.evidence.push(makeEvidence("price", product.price, "amazon-selector", "Amazon current price", "high", matched.find((item) => AMAZON_SELECTORS.price.includes(item))));
      if (product.countryOfOrigin) product.evidence.push(makeEvidence("countryOfOrigin", product.countryOfOrigin, "amazon-selector", "Amazon product details", "high"));
      if (product.careInstructions) product.evidence.push(makeEvidence("careInstructions", product.careInstructions, "amazon-selector", "Amazon product details", "high"));
      if (product.shipperSeller) product.evidence.push(makeEvidence("shipperSeller", product.shipperSeller, "amazon-selector", "Amazon product details", "high"));
      return result(product, matched, false, { title: product.title, priceText, productId: product.productId, evidenceText: evidenceText2.slice(0, 3e3) }, rejected);
    }
  };

  // shared/parsers/genericJsonLdParser.ts
  function asRecords(value) {
    if (Array.isArray(value)) return value.flatMap(asRecords);
    if (!value || typeof value !== "object") return [];
    const record = value;
    return [record, ...asRecords(record["@graph"])];
  }
  function types(record) {
    const value = record["@type"];
    return (Array.isArray(value) ? value : [value]).map(String);
  }
  function readJsonLdProducts(document2) {
    const products = [];
    const rejected = [];
    document2.querySelectorAll('script[type="application/ld+json"]').forEach((script, index) => {
      try {
        const parsed = JSON.parse(script.textContent || "null");
        products.push(...asRecords(parsed).filter((item) => types(item).some((type) => type === "Product" || type === "ProductGroup")));
      } catch {
        rejected.push(`Malformed JSON-LD ignored at script ${index + 1}.`);
      }
    });
    return { products, rejected };
  }
  function stringValue(value) {
    if (Array.isArray(value)) return stringValue(value[0]);
    if (value && typeof value === "object") return cleanText(String(value.name ?? value.url ?? ""));
    return typeof value === "string" || typeof value === "number" ? cleanText(String(value)) : null;
  }
  function selectRecord(records, url) {
    const current = new URL(url);
    const direct = records.find((record) => types(record).includes("Product") && stringValue(record.url)?.includes(current.pathname));
    const group = records.find((record) => types(record).includes("ProductGroup"));
    if (!group) return direct ?? records.find((record) => types(record).includes("Product")) ?? null;
    const variants = Array.isArray(group.hasVariant) ? group.hasVariant.filter((item) => Boolean(item && typeof item === "object")) : [];
    const variant = variants.find((item) => {
      const offer = Array.isArray(item.offers) ? item.offers[0] : item.offers;
      const variantUrl = stringValue(offer?.url) ?? stringValue(item.url);
      return variantUrl?.includes(current.pathname);
    }) ?? variants[0];
    return { ...group, ...variant ?? {}, name: variant?.name ?? group.name, description: variant?.description ?? group.description, brand: variant?.brand ?? group.brand, category: variant?.category ?? group.category, material: variant?.material ?? group.material, productGroupID: group.productGroupID };
  }
  function offerRecord(record) {
    const offers = Array.isArray(record.offers) ? record.offers[0] : record.offers;
    return offers && typeof offers === "object" ? offers : null;
  }
  function additionalText(record) {
    const properties = Array.isArray(record.additionalProperty) ? record.additionalProperty : [];
    return properties.filter((item) => Boolean(item && typeof item === "object")).map((item) => `${stringValue(item.name) ?? ""}: ${stringValue(item.value) ?? ""}`.trim()).filter(Boolean);
  }
  var genericJsonLdParser = {
    id: "generic-json-ld",
    canParse(document2) {
      return readJsonLdProducts(document2).products.length > 0;
    },
    parse(document2, url) {
      const { products, rejected } = readJsonLdProducts(document2);
      const record = selectRecord(products, url) ?? {};
      const offer = offerRecord(record);
      const retailer = cleanText(document2.querySelector('meta[property="og:site_name"]')?.getAttribute("content")) ?? new URL(url).hostname.replace(/^www\d?\./, "");
      const product = emptyProduct(url, retailer, "generic-json-ld");
      product.title = stringValue(record.name);
      product.description = stringValue(record.description);
      product.brand = stringValue(record.brand);
      product.category = stringValue(record.category);
      product.productId = stringValue(record.sku) ?? stringValue(record.productID) ?? stringValue(record.productGroupID) ?? stringValue(record.gtin);
      product.imageUrl = stringValue(record.image);
      const rawPrice = stringValue(offer?.price) ?? stringValue(record.price);
      const price = parsePriceText(rawPrice);
      product.price = price.price;
      product.currency = stringValue(offer?.priceCurrency) ?? price.currency;
      const extras = additionalText(record);
      product.featureText = extras;
      const materialText = [stringValue(record.material), product.description, ...extras].filter(Boolean).join(" \xB7 ");
      rejected.push(...applyTextEvidence(product, materialText, "json-ld", "Schema.org Product data", 'script[type="application/ld+json"]'));
      product.weightGrams = parseWeightGrams(extras.join(" "));
      if (product.title) product.evidence.push(makeEvidence("title", product.title, "json-ld", "Schema.org Product data", "high"));
      if (product.price !== null) product.evidence.push(makeEvidence("price", product.price, "json-ld", "Schema.org Product offer", "high"));
      if (product.description) product.evidence.push(makeEvidence("description", product.description, "json-ld", "Schema.org Product data", "high"));
      if (product.brand) product.evidence.push(makeEvidence("brand", product.brand, "json-ld", "Schema.org Product data", "high"));
      return result(product, ['script[type="application/ld+json"]'], true, { name: record.name, material: record.material, offers: record.offers, additionalProperty: record.additionalProperty }, rejected);
    }
  };

  // shared/parsers/genericMetaParser.ts
  function meta(document2, property) {
    return cleanText(document2.querySelector(`meta[property="${property}"],meta[name="${property}"]`)?.getAttribute("content"));
  }
  var genericMetaParser = {
    id: "generic-meta",
    canParse(document2, url) {
      return meta(document2, "og:type") === "product" || Boolean(document2.querySelector('[itemtype*="schema.org/Product"],[itemprop="price"]')) || /\/products?\//i.test(new URL(url).pathname);
    },
    parse(document2, url) {
      const matched = [];
      const retailer = meta(document2, "og:site_name") ?? new URL(url).hostname.replace(/^www\d?\./, "");
      const product = emptyProduct(url, retailer, "generic-meta");
      product.title = meta(document2, "og:title") ?? selectorText(document2, ['[itemprop="name"]', "main h1", "h1"], matched);
      product.description = meta(document2, "og:description") ?? selectorText(document2, ['[itemprop="description"]', 'main [class*="description" i]'], matched);
      product.imageUrl = meta(document2, "og:image:secure_url") ?? meta(document2, "og:image") ?? selectorAttribute(document2, ['[itemprop="image"]'], "content", matched) ?? selectorAttribute(document2, ['[itemprop="image"] img', "main img"], "src", matched);
      product.brand = meta(document2, "product:brand") ?? selectorText(document2, ['[itemprop="brand"]'], matched);
      product.category = meta(document2, "product:category") ?? selectorText(document2, ['[itemprop="category"]'], matched);
      product.productId = selectorText(document2, ['[itemprop="sku"]', '[itemprop="gtin"]'], matched);
      const rawPrice = meta(document2, "product:price:amount") ?? meta(document2, "og:price:amount") ?? selectorAttribute(document2, ['[itemprop="price"]'], "content", matched) ?? selectorText(document2, ['[itemprop="price"]', 'main [class*="price" i]'], matched);
      const parsedPrice = parsePriceText(rawPrice);
      product.price = parsedPrice.price;
      product.currency = meta(document2, "product:price:currency") ?? meta(document2, "og:price:currency") ?? selectorAttribute(document2, ['[itemprop="priceCurrency"]'], "content", matched) ?? parsedPrice.currency;
      const materialText = selectorText(document2, ['[itemprop="material"]', 'main [class*="material" i]', 'main [class*="composition" i]'], matched) ?? product.description ?? "";
      const rejected = applyTextEvidence(product, materialText, meta(document2, "og:type") === "product" ? "meta" : "visible-page", meta(document2, "og:type") === "product" ? "Open Graph product metadata" : "HTML product metadata");
      if (product.title) product.evidence.push(makeEvidence("title", product.title, meta(document2, "og:title") ? "meta" : "visible-page", meta(document2, "og:title") ? "Open Graph metadata" : "Visible product heading", meta(document2, "og:title") ? "high" : "medium"));
      if (product.price !== null) product.evidence.push(makeEvidence("price", product.price, meta(document2, "product:price:amount") ? "meta" : "visible-page", "Product price metadata", "high"));
      return result(product, matched, false, { title: product.title, rawPrice, materialText }, rejected);
    }
  };

  // shared/parsers/genericVisibleParser.ts
  var PRODUCT_PATH = /\/(?:product|products|p|item)\//i;
  var genericVisibleParser = {
    id: "generic-visible",
    canParse(document2, url) {
      return PRODUCT_PATH.test(new URL(url).pathname) && Boolean(document2.querySelector("main h1,h1"));
    },
    parse(document2, url) {
      const matched = [];
      const product = emptyProduct(url, new URL(url).hostname.replace(/^www\./, ""), "generic-visible");
      product.title = selectorText(document2, ["main h1", "h1"], matched);
      const main = document2.querySelector("main");
      const text = cleanText(main?.textContent) ?? "";
      product.description = selectorText(document2, ['main [class*="description" i]', 'main [class*="details" i]'], matched);
      const priceText = selectorText(document2, ['main [class*="price" i]', '[itemprop="price"]'], matched);
      const price = parsePriceText(priceText);
      product.price = price.price;
      product.currency = price.currency;
      const rejected = applyTextEvidence(product, text.slice(0, 12e3), "visible-page", "Visible product page text", "main");
      if (product.title) product.evidence.push(makeEvidence("title", product.title, "visible-page", "Visible product heading", "medium", matched[0]));
      return result(product, matched, false, { title: product.title, priceText, visibleTextSample: text.slice(0, 1e3) }, rejected);
    }
  };

  // shared/parsers/hmParser.ts
  var hmParser = {
    id: "hm",
    canParse(_document, url) {
      return /(^|\.)hm\.com$/i.test(new URL(url).hostname) && /productpage\./i.test(new URL(url).pathname);
    },
    parse(document2, url) {
      const base = genericJsonLdParser.canParse(document2, url) ? genericJsonLdParser.parse(document2, url) : null;
      const product = base?.product ?? { ...genericJsonLdParser.parse(document2, url).product };
      product.parserUsed = "hm";
      product.retailer = "H&M";
      const matched = [...base?.diagnostics.matchedSelectors ?? []];
      const materialSection = document2.querySelector("#section-materialsAndCareAccordion") ?? [...document2.querySelectorAll("main div,main section")].find((element) => /Composition/i.test(element.textContent || "") && /Care instructions/i.test(element.textContent || "") && element.textContent.length < 5e3);
      const detailsSection = [...document2.querySelectorAll("main div,main section")].find((element) => /Art\. No\./i.test(element.textContent || "") && /Description/i.test(element.textContent || "") && element.textContent.length < 5e3);
      const materialText = cleanText(materialSection?.textContent) ?? "";
      const detailText = cleanText(detailsSection?.textContent) ?? "";
      if (materialSection) matched.push(materialSection.id ? `#${materialSection.id}` : "H&M material accordion");
      const rejected = applyTextEvidence(product, materialText, "visible-page", "H&M Material & Care section", materialSection?.id ? `#${materialSection.id}` : void 0);
      product.weightGrams = parseWeightGrams(detailText);
      product.productId = url.match(/productpage\.(\d+)\.html/i)?.[1] ?? product.productId;
      product.countryOfOrigin = detailText.match(/(?:Country of production|Imported)\s*:?\s*([A-Za-z ]+)/i)?.[1]?.trim() ?? null;
      product.careInstructions = materialText.match(/Care instructions\s*(.*?)(?:Bring your|Material:|Materials in this|$)/i)?.[1]?.trim() ?? null;
      if (product.weightGrams !== null) product.evidence.push(makeEvidence("weightGrams", Math.round(product.weightGrams), "visible-page", "H&M Description & fit", "high"));
      if (product.careInstructions) product.evidence.push(makeEvidence("careInstructions", product.careInstructions, "visible-page", "H&M Material & Care section", "high"));
      return result(product, matched, true, { ...base?.diagnostics.rawFields ?? {}, materialText: materialText.slice(0, 1800), detailText: detailText.slice(0, 1800) }, [...base?.diagnostics.rejectedFields ?? [], ...rejected]);
    }
  };

  // shared/parsers/manualParser.ts
  var manualParser = {
    id: "manual",
    canParse() {
      return true;
    },
    parse(document2, url) {
      const product = emptyProduct(url, new URL(url).hostname.replace(/^www\./, ""), "manual");
      product.title = document2.title || null;
      return result(product, [], false, { documentTitle: document2.title });
    }
  };
  function applyManualCorrections(product, corrections) {
    const next = { ...product, materials: [...product.materials], certifications: [...product.certifications], sustainabilityClaims: [...product.sustainabilityClaims], packaging: { ...product.packaging }, evidence: [...product.evidence], missingFields: [...product.missingFields], parserUsed: product.parserUsed === "manual" ? "manual" : product.parserUsed };
    const missing = new Set(corrections.markNotDisclosed ?? []);
    if (corrections.title?.trim()) {
      next.title = corrections.title.trim();
      next.evidence.push(makeEvidence("title", next.title, "manual-user-input", "Provided by user", "medium"));
    }
    if (missing.has("materials")) next.materials = [];
    else if (corrections.materialText?.trim()) {
      next.materials = [];
      next.materialCompositionUncertain = false;
      applyTextEvidence(next, corrections.materialText.trim(), "manual-user-input", "Provided by user");
    }
    if (missing.has("recycledContent")) next.recycledContentPercentage = null;
    else if (typeof corrections.recycledContentPercentage === "number" && Number.isFinite(corrections.recycledContentPercentage)) {
      next.recycledContentPercentage = Math.max(0, Math.min(100, corrections.recycledContentPercentage));
      next.evidence.push(makeEvidence("recycledContentPercentage", next.recycledContentPercentage, "manual-user-input", "Provided by user", "medium"));
    }
    const manualPackaging = (description, source, uncertain) => ({ description, material: description.match(/recycled[- ]?(?:cardboard|card|paper)|cardboard|paper|plastic/i)?.[0] ?? null, recycledContentPercentage: null, reducedPackagingOption: /reduced|minimal|plastic[- ]free/i.test(description) ? true : null, sourceType: "user-provided", sourceLabel: source?.trim() ? `User-provided \xB7 ${source.trim()}` : "User-provided", confidence: uncertain ? "low" : "medium" });
    if (missing.has("fulfilmentPackaging")) next.packaging.fulfilment = null;
    else if (corrections.fulfilmentPackaging?.trim()) {
      next.packaging.fulfilment = manualPackaging(corrections.fulfilmentPackaging.trim(), corrections.fulfilmentPackagingSource, corrections.fulfilmentPackagingUncertain);
      next.evidence.push(makeEvidence("fulfilmentPackaging", corrections.fulfilmentPackaging.trim(), "manual-user-input", "Provided by user", corrections.fulfilmentPackagingUncertain ? "low" : "medium"));
    }
    if (missing.has("manufacturerPackaging")) next.packaging.manufacturer = null;
    else if (corrections.manufacturerPackaging?.trim()) {
      next.packaging.manufacturer = manualPackaging(corrections.manufacturerPackaging.trim(), corrections.manufacturerPackagingSource, corrections.manufacturerPackagingUncertain);
      next.evidence.push(makeEvidence("manufacturerPackaging", corrections.manufacturerPackaging.trim(), "manual-user-input", "Provided by user", corrections.manufacturerPackagingUncertain ? "low" : "medium"));
    }
    if (corrections.certificationNotDisclosed) next.certifications = [];
    else if (corrections.certificationClaim?.trim()) {
      const rawClaim = corrections.certificationClaim.trim();
      const detected = detectCertificationEvidence(rawClaim, "User-provided evidence", "user-provided").certifications[0];
      const definition = detected ? CERTIFICATION_REGISTRY.find((item) => item.id === detected.certificationId) : null;
      next.certifications = [{ certificationId: detected?.certificationId ?? null, displayedName: detected?.displayedName ?? "Unverified sustainability claim", rawClaim, status: corrections.certificationAsSellerClaim ? "seller-claim" : "unverified", evidenceSource: "user-provided", sourceLabel: "User-provided evidence", ...corrections.certificationSourceUrl?.trim() ? { sourceUrl: corrections.certificationSourceUrl.trim() } : {}, confidence: "low", affectsEnvironmentalScore: false, affectsPeopleInformation: definition?.peopleInformationEligible ?? false }];
    }
    const completed = result(next, [], false, { manualCorrections: corrections });
    return completed.product;
  }

  // shared/parsers/nikeParser.ts
  var nikeParser = {
    id: "nike",
    canParse(_document, url) {
      return /(^|\.)nike\.com$/i.test(new URL(url).hostname) && /\/t\//i.test(new URL(url).pathname);
    },
    parse(document2, url) {
      const base = genericJsonLdParser.canParse(document2, url) ? genericJsonLdParser.parse(document2, url) : null;
      const product = base?.product ?? genericJsonLdParser.parse(document2, url).product;
      product.parserUsed = "nike";
      product.retailer = "Nike";
      const matched = [...base?.diagnostics.matchedSelectors ?? []];
      const headings = [...document2.querySelectorAll("h2,h3,h4")];
      const productDetailsHeading = headings.find((heading) => /^Product Details$/i.test(cleanText(heading.textContent) ?? ""));
      const detailsContainer = productDetailsHeading?.parentElement;
      const detailsText = cleanText(detailsContainer?.textContent) ?? cleanText(document2.querySelector("main")?.textContent) ?? "";
      if (detailsContainer) matched.push("Nike Product Details section");
      const rejected = applyTextEvidence(product, detailsText, "visible-page", "Nike Product Details section");
      product.careInstructions = detailsText.match(/\b(Machine wash(?: [^\n·]*)?)/i)?.[1] ?? (/machine wash/i.test(detailsText) ? "Machine wash" : null);
      product.countryOfOrigin = /\bImported\b/i.test(detailsText) ? "Imported; country not disclosed" : null;
      product.productId = new URL(url).pathname.split("/").filter(Boolean).at(-1) ?? product.productId;
      product.imageUrl = product.imageUrl ?? selectorAttribute(document2, ['meta[property="og:image"]'], "content", matched);
      if (product.price === null) {
        const priceText = cleanText(document2.querySelector("main")?.textContent)?.match(/[$£€]\s?\d+(?:[.,]\d{2})?/)?.[0];
        const price = parsePriceText(priceText);
        product.price = price.price;
        product.currency = price.currency;
      }
      if (product.careInstructions) product.evidence.push(makeEvidence("careInstructions", product.careInstructions, "visible-page", "Nike Product Details section", "high"));
      return result(product, matched, true, { ...base?.diagnostics.rawFields ?? {}, detailsText: detailsText.slice(0, 1800) }, [...base?.diagnostics.rejectedFields ?? [], ...rejected]);
    }
  };

  // shared/parsers/shopifyParser.ts
  function looksShopify(document2, url) {
    return /\/products\//i.test(new URL(url).pathname) && (Boolean(document2.querySelector('script[src*="shopify" i],link[href*="cdn.shopify.com" i]')) || /Shopify/i.test(document2.documentElement.innerHTML.slice(0, 1e4)));
  }
  var shopifyParser = {
    id: "shopify",
    canParse(document2, url) {
      return looksShopify(document2, url);
    },
    parse(document2, url) {
      const base = genericJsonLdParser.canParse(document2, url) ? genericJsonLdParser.parse(document2, url) : null;
      const product = base?.product ?? genericJsonLdParser.parse(document2, url).product;
      product.parserUsed = "shopify";
      product.retailer = cleanText(document2.querySelector('meta[property="og:site_name"]')?.getAttribute("content")) ?? product.retailer;
      const matched = [...base?.diagnostics.matchedSelectors ?? []];
      const mainText = cleanText(document2.querySelector("main")?.textContent) ?? "";
      const detailSection = [...document2.querySelectorAll("main div,main section")].filter((element) => element.children.length < 30 && /(?:Details|Care|Content|Composition)/i.test(element.textContent || "") && element.textContent.length < 5e3).sort((a, b) => (a.textContent?.length ?? 0) - (b.textContent?.length ?? 0)).at(-1);
      const detailText = cleanText(detailSection?.textContent) ?? mainText.slice(0, 1e4);
      if (detailSection) matched.push("Shopify visible product details");
      const rejected = applyTextEvidence(product, detailText, "visible-page", `${product.retailer} visible product details`);
      product.careInstructions = detailText.match(/\b(Machine wash[^.·\n]*)/i)?.[1]?.trim() ?? null;
      product.countryOfOrigin = detailText.match(/\bMade (?:responsibly |with love )?in\s+([A-Za-z ]+)/i)?.[1]?.trim() ?? null;
      if (product.countryOfOrigin) product.evidence.push(makeEvidence("countryOfOrigin", product.countryOfOrigin, "visible-page", `${product.retailer} visible product details`, "high"));
      return result(product, matched, true, { ...base?.diagnostics.rawFields ?? {}, detailText: detailText.slice(0, 2500) }, [...base?.diagnostics.rejectedFields ?? [], ...rejected]);
    }
  };

  // shared/parsers/threadlyParser.ts
  function jsonValue(value, fallback) {
    if (!value) return fallback;
    try {
      return JSON.parse(value);
    } catch {
      return fallback;
    }
  }
  var threadlyParser = {
    id: "threadly",
    canParse(document2) {
      return Boolean(document2.querySelector('[data-ecomind-demo-product="true"]'));
    },
    parse(document2, url) {
      const matched = ['[data-ecomind-demo-product="true"]'];
      const container = document2.querySelector('[data-ecomind-demo-product="true"]');
      const local = PRODUCT_RECORDS.find((item) => item.id === container.dataset.productId);
      const product = emptyProduct(url, "Threadly demo", "threadly");
      product.productId = local?.id ?? container.dataset.productId ?? null;
      product.title = cleanText(container.querySelector(".product-info h1")?.textContent);
      const price = parsePriceText(cleanText(container.querySelector(".product-price")?.textContent));
      product.price = price.price;
      product.currency = container.dataset.currency ?? price.currency;
      product.imageUrl = container.querySelector(".product-gallery__main img")?.src ?? null;
      const paragraphs = container.querySelectorAll(".store-details p");
      product.description = cleanText(paragraphs[0]?.textContent);
      const listingText = cleanText(paragraphs[1]?.textContent) ?? container.dataset.listingText ?? "";
      product.featureText = listingText ? [listingText] : [];
      const rejected = applyTextEvidence(product, listingText, "visible-page", "Threadly sample product listing", ".store-details");
      product.recycledContentPercentage = container.dataset.recycledContent && container.dataset.recycledContent !== "null" ? Number(container.dataset.recycledContent) : null;
      product.packaging = local?.packaging ?? { fulfilment: null, manufacturer: null };
      product.certifications = local?.certifications ?? [];
      product.category = local?.category ?? "Clothing";
      product.brand = product.title?.split(" ")[0] ?? null;
      const sources = jsonValue(container.dataset.sources, local?.sources ?? []);
      for (const source of sources) product.evidence.push(makeEvidence("demo-source", source.note ?? source.label, source.type === "listing" ? "visible-page" : "ecomind-estimate", source.label, source.type === "listing" ? "high" : "low"));
      if (product.title) product.evidence.push(makeEvidence("title", product.title, "visible-page", "Threadly sample product listing", "high", ".product-info h1"));
      return result(product, matched, false, { localProductId: local?.id, listingText, storedConfidence: local ? calculateConfidence(local) : null }, rejected);
    }
  };

  // shared/parsers/parserRegistry.ts
  var parserRegistry = [
    amazonParser,
    hmParser,
    nikeParser,
    shopifyParser,
    threadlyParser,
    genericJsonLdParser,
    genericMetaParser,
    genericVisibleParser,
    manualParser
  ];
  function parseProductPage(document2, url) {
    const parser = parserRegistry.find((candidate) => candidate.canParse(document2, url)) ?? manualParser;
    return parser.parse(document2, url);
  }

  // shared/realProductScoring.ts
  var MATERIAL_SCORES = {
    "Regenerative Organic Cotton": [55, 72],
    Cotton: [38, 58],
    "Organic cotton": [55, 72],
    "Recycled cotton": [72, 88],
    Polyester: [20, 38],
    "Recycled polyester": [52, 72],
    Nylon: [18, 35],
    "Recycled nylon": [50, 70],
    Elastane: [15, 32],
    Linen: [62, 82],
    Hemp: [68, 86],
    Wool: [35, 60],
    "Recycled wool": [62, 82],
    "Viscose family": [38, 62],
    Modal: [48, 68],
    Lyocell: [68, 88],
    Acrylic: [18, 34],
    Silk: [30, 55],
    Leather: [10, 30],
    "Recycled fibres": [55, 78]
  };
  var factorEvidence = (product, field) => product.evidence.filter((item) => item.field === field || field === "materials" && item.field === "materials");
  function materialFactor(product) {
    if (!product.materials.length) return { status: "unknown", score: null, evidence: [] };
    const knownPercent = product.materials.every((item) => item.percentage !== null);
    const total = product.materials.reduce((sum, item) => sum + (item.percentage ?? 0), 0);
    const ranges = product.materials.map((item) => MATERIAL_SCORES[item.name] ?? [30, 55]);
    const min = ranges.reduce((sum, range, index) => sum + range[0] * (knownPercent ? (product.materials[index].percentage ?? 0) / Math.max(total, 1) : 1 / ranges.length), 0);
    const max = ranges.reduce((sum, range, index) => sum + range[1] * (knownPercent ? (product.materials[index].percentage ?? 0) / Math.max(total, 1) : 1 / ranges.length), 0);
    const score = Math.round((min + max) / 2);
    return { status: "estimated", score, range: [Math.round(min), Math.round(max)], evidence: [...factorEvidence(product, "materials"), { field: "material-factor", value: `${Math.round(min)}\u2013${Math.round(max)}`, sourceType: "ecomind-estimate", sourceLabel: "EcoMind prototype material factors", confidence: "low" }] };
  }
  function recycledFactor(product) {
    if (product.recycledContentPercentage === null) return { status: "unknown", score: null, evidence: [] };
    return { status: "known", score: Math.round(product.recycledContentPercentage), evidence: factorEvidence(product, "recycledContentPercentage") };
  }
  function packagingFactor(product, stage) {
    const packaging = product.packaging[stage];
    const field = stage === "fulfilment" ? "fulfilmentPackaging" : "manufacturerPackaging";
    if (!packaging) return { status: "unknown", score: null, evidence: [] };
    const lower = `${packaging.description ?? ""} ${packaging.material ?? ""}`.toLowerCase();
    const score = /plastic[- ]free|minimal|recycled card|recycled paper/.test(lower) || packaging.reducedPackagingOption === true ? 82 : /paper|card/.test(lower) ? 65 : /plastic|polybag/.test(lower) ? 25 : 50;
    const evidence = [...factorEvidence(product, field), { field: `${field}-factor`, value: score, sourceType: "ecomind-estimate", sourceLabel: "EcoMind prototype packaging factors", confidence: "low" }];
    const estimated = packaging.sourceType === "retailer-policy" || packaging.sourceType === "ecomind-estimate" || packaging.confidence === "low";
    return estimated ? { status: "estimated", score, range: [Math.max(0, score - 15), Math.min(100, score + 15)], evidence } : { status: "known", score, evidence };
  }
  function scoreRealProduct(product) {
    const factors = {
      materials: materialFactor(product),
      carbon: { status: "unknown", score: null, evidence: [] },
      recycled: recycledFactor(product),
      durability: { status: "unknown", score: null, evidence: [] },
      fulfilmentPackaging: packagingFactor(product, "fulfilment"),
      manufacturerPackaging: packagingFactor(product, "manufacturer")
    };
    const known = Object.keys(factors).filter((key) => factors[key].status !== "unknown");
    const knownWeight = known.reduce((sum, key) => sum + SCORE_WEIGHTS[key], 0);
    const weightedMid = known.reduce((sum, key) => sum + (factors[key].score ?? 0) * SCORE_WEIGHTS[key], 0);
    const baseScore = knownWeight > 0 ? Math.round(weightedMid / knownWeight) : null;
    const adjustment = certificationAdjustment(product.certifications);
    const score = baseScore === null ? null : Math.min(100, baseScore + adjustment);
    const lowerKnown = known.reduce((sum, key) => {
      const factor = factors[key];
      const value = factor.status === "estimated" ? factor.range[0] : factor.score ?? 0;
      return sum + value * SCORE_WEIGHTS[key];
    }, 0);
    const upperKnown = known.reduce((sum, key) => {
      const factor = factors[key];
      const value = factor.status === "estimated" ? factor.range[1] : factor.score ?? 0;
      return sum + value * SCORE_WEIGHTS[key];
    }, 0);
    const unknownWeight = 1 - knownWeight;
    const range = score === null ? null : [Math.min(100, Math.floor(lowerKnown) + adjustment), Math.min(100, Math.ceil(upperKnown + unknownWeight * 100) + adjustment)];
    const hasCompleteComposition = product.materials.length > 0 && product.materials.every((material) => material.percentage !== null) && !product.materialCompositionUncertain;
    const canScore = product.isClothing && hasCompleteComposition;
    const grade = !canScore || score === null ? null : score >= 80 ? "A" : score >= 65 ? "B" : score >= 45 ? "C" : score >= 25 ? "D" : "E";
    const packagingMissing = !product.packaging.fulfilment || !product.packaging.manufacturer;
    const hasEstimatedPackaging = [product.packaging.fulfilment, product.packaging.manufacturer].some((item) => item?.sourceType === "retailer-policy" || item?.confidence === "low");
    const confidence = known.length >= 5 && !packagingMissing && !hasEstimatedPackaging && !product.materialCompositionUncertain ? "High" : known.length >= 2 && !product.materialCompositionUncertain ? "Medium" : "Low";
    const explanation = !product.isProduct ? "EcoMind could not confirm that this is a product page." : !product.isClothing ? "Product detected, but EcoMind currently scores clothing and textile products." : !canScore ? "A complete, internally consistent percentage composition is needed before EcoMind can calculate a provisional score." : `${known.length} of 6 factors contain sufficient evidence. Missing fulfilment or manufacturer packaging stays unknown and can change the score.`;
    return { score: canScore ? score : null, range: canScore ? range : null, grade, confidence, factors, knownFactorCount: known.length, provisional: true, canScore, explanation, baseScore: canScore ? baseScore : null, certificationAdjustment: adjustment };
  }

  // shared/ecoPoints.ts
  var ECO_POINT_RULES = {
    compareGreenerAlternative: 5,
    saveLowerImpactOption: 5,
    chooseLowerImpactOption: 10,
    repairOrReuseItem: 20,
    avoidUnnecessaryPurchase: 25,
    completeWeeklyChallenge: 30
  };
  var WEEKLY_CHALLENGES = [
    { id: "repair-reuse", title: "Repair or reuse one item", description: "Extend the useful life of something you already own.", actionType: "completeWeeklyChallenge", reward: ECO_POINT_RULES.completeWeeklyChallenge, selfReported: true, progressActionType: "repairOrReuseItem" },
    { id: "compare-products", title: "Compare before deciding", description: "Compare two products and review the disclosed evidence.", actionType: "completeWeeklyChallenge", reward: ECO_POINT_RULES.completeWeeklyChallenge, selfReported: false, progressActionType: "compareGreenerAlternative" },
    { id: "pause-purchase", title: "Pause one unnecessary purchase", description: "Record a mindful decision that you do not need a new item.", actionType: "completeWeeklyChallenge", reward: ECO_POINT_RULES.completeWeeklyChallenge, selfReported: true, progressActionType: "avoidUnnecessaryPurchase" }
  ];
  var SELF_REPORTED_WEEKLY_CAPS = {
    repairOrReuseItem: 1,
    avoidUnnecessaryPurchase: 1,
    completeWeeklyChallenge: 3
  };
  function getPeriodStart(period, now = /* @__PURE__ */ new Date()) {
    if (period === "all") return /* @__PURE__ */ new Date(0);
    if (period === "month") return new Date(now.getFullYear(), now.getMonth(), 1);
    const start = new Date(now);
    const day = (start.getDay() + 6) % 7;
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - day);
    return start;
  }
  function getPeriodEnd(period, now = /* @__PURE__ */ new Date()) {
    if (period === "all") return null;
    const start = getPeriodStart(period, now);
    if (period === "month") return new Date(start.getFullYear(), start.getMonth() + 1, 1);
    const end = new Date(start);
    end.setDate(end.getDate() + 7);
    return end;
  }
  function eventsForPeriod(events, period, now = /* @__PURE__ */ new Date()) {
    const start = getPeriodStart(period, now).getTime();
    const end = getPeriodEnd(period, now)?.getTime() ?? Infinity;
    return events.filter((event) => event.actionType !== "legacy-demo-balance" && new Date(event.timestamp).getTime() >= start && new Date(event.timestamp).getTime() < end);
  }
  function neutralNickname(seed = 247) {
    return `Green Koala ${Math.abs(seed) % 1e3}`;
  }
  function canAddPointEvent(events, candidate, now = /* @__PURE__ */ new Date()) {
    if (events.some((event) => event.deduplicationKey === candidate.deduplicationKey)) return false;
    const cap = SELF_REPORTED_WEEKLY_CAPS[candidate.actionType];
    if (!candidate.selfReported || !cap) return true;
    return eventsForPeriod(events, "week", now).filter((event) => event.actionType === candidate.actionType && event.selfReported).length < cap;
  }
  function addPointEvent(events, candidate, now = /* @__PURE__ */ new Date()) {
    return canAddPointEvent(events, candidate, now) ? [candidate, ...events] : events;
  }
  function createPointEvent(input) {
    const timestamp = input.timestamp ?? (/* @__PURE__ */ new Date()).toISOString();
    return { ...input, id: input.id ?? `${input.deduplicationKey}-${timestamp}`, timestamp };
  }
  function migrateLegacyPointEvents(existing, legacyPoints, label = "Previous demo balance") {
    if (Array.isArray(existing) && existing.length) return existing;
    if (!legacyPoints || legacyPoints <= 0) return [];
    return [createPointEvent({ id: "legacy-demo-balance", actionType: "legacy-demo-balance", points: legacyPoints, timestamp: "1970-01-01T00:00:00.000Z", source: "migration", deduplicationKey: "legacy-demo-balance", title: label, detail: "Migrated from an earlier local state. Excluded from weekly rankings.", selfReported: false })];
  }

  // shared/trafficLight.ts
  var TRAFFIC_LIGHT_THRESHOLDS = {
    green: { min: 70, max: 100, label: "Lower impact", shortExplanation: "Lower impact according to the EcoMind prototype methodology and available evidence." },
    amber: { min: 40, max: 69, label: "Mixed impact", shortExplanation: "A mix of stronger and weaker factors according to the available evidence." },
    red: { min: 0, max: 39, label: "Higher impact", shortExplanation: "Higher impact according to the EcoMind prototype methodology and available evidence." },
    grey: { label: "Not enough information", shortExplanation: "EcoMind does not have sufficient evidence for a reliable traffic-light result." }
  };
  function getTrafficLightStatus(score, hasSufficientEvidence) {
    if (score === null || !hasSufficientEvidence) return { colour: "grey", label: TRAFFIC_LIGHT_THRESHOLDS.grey.label, shortExplanation: TRAFFIC_LIGHT_THRESHOLDS.grey.shortExplanation };
    if (score >= TRAFFIC_LIGHT_THRESHOLDS.green.min) return { colour: "green", label: TRAFFIC_LIGHT_THRESHOLDS.green.label, shortExplanation: TRAFFIC_LIGHT_THRESHOLDS.green.shortExplanation };
    if (score >= TRAFFIC_LIGHT_THRESHOLDS.amber.min) return { colour: "amber", label: TRAFFIC_LIGHT_THRESHOLDS.amber.label, shortExplanation: TRAFFIC_LIGHT_THRESHOLDS.amber.shortExplanation };
    return { colour: "red", label: TRAFFIC_LIGHT_THRESHOLDS.red.label, shortExplanation: TRAFFIC_LIGHT_THRESHOLDS.red.shortExplanation };
  }
  function formatTrafficLightScore(score, provisional, range) {
    if (score === null) return "Score unavailable";
    const scoreText = `${provisional ? "~" : ""}${Math.round(score)}/100`;
    return range ? `${scoreText} \xB7 range ${range[0]}\u2013${range[1]}` : scoreText;
  }
  function trafficLightAccessibleText(status, score, provisional, confidence, range) {
    const scoreText = score === null ? "score unavailable" : `${provisional ? "provisional score approximately " : "score "}${Math.round(score)} out of 100${range ? `, possible range ${range[0]} to ${range[1]}` : ""}`;
    const grade = score === null ? "" : ` Grade ${score >= 80 ? "A" : score >= 65 ? "B" : score >= 45 ? "C" : score >= 25 ? "D" : "E"}.`;
    return `Traffic-light status: ${status.colour}, ${status.label.toLowerCase()}, ${scoreText}.${grade} ${confidence} confidence.`;
  }

  // shared/supabaseBackend.ts
  function localEventToQueueItem(event, source, accountId) {
    if (event.actionType === "analysis" || event.actionType === "legacy-demo-balance") return null;
    if (!event.deduplicationKey || Number.isNaN(Date.parse(event.timestamp))) return null;
    const allowed = { compareGreenerAlternative: 5, saveLowerImpactOption: 5, chooseLowerImpactOption: 10, repairOrReuseItem: 20, avoidUnnecessaryPurchase: 25, completeWeeklyChallenge: 30 };
    if (allowed[event.actionType] !== event.points) return null;
    const challengeId = event.actionType === "completeWeeklyChallenge" ? event.deduplicationKey.match(/^weekly-\d{4}-\d{2}-\d{2}-(.+)$/)?.[1] ?? "" : "";
    if (event.actionType === "completeWeeklyChallenge" && !challengeId) return null;
    return { id: `import:${event.deduplicationKey}`, accountId, actionType: event.actionType, deduplicationKey: event.deduplicationKey, source, localTimestamp: event.timestamp, metadata: { localTimestamp: event.timestamp, ...challengeId ? { challengeId } : {} }, status: "waiting_to_sync" };
  }

  // extension/src/shared.ts
  var STORAGE_KEY = "ecomindExtensionStateV2";
  var MASCOT_OPTIONS = [
    { id: "koala", label: "Koala", glyph: "\u{1F428}" },
    { id: "panda", label: "Panda", glyph: "\u{1F43C}" },
    { id: "polar-bear", label: "Polar Bear", glyph: "\u{1F43B}\u200D\u2744\uFE0F" },
    { id: "leaf", label: "Leaf", glyph: "\u{1F33F}" },
    { id: "sprout", label: "Sprout", glyph: "\u{1F331}" }
  ];
  function mascotDetails(id) {
    return MASCOT_OPTIONS.find((option) => option.id === id) ?? MASCOT_OPTIONS[0];
  }
  var DEFAULT_EXTENSION_STATE = {
    schemaVersion: 5,
    points: 0,
    wishlist: [],
    completedActions: [],
    activities: [],
    pointEvents: [],
    leaderboardProfile: { optedIn: false, displayName: neutralNickname(), joinedAt: null },
    backendAccountId: null,
    syncQueue: [],
    importedForAccounts: [],
    manualCorrections: {},
    preferences: {
      showWidgetAfterAnalysis: true,
      diagnosticsEnabled: false,
      mascot: "koala"
    }
  };
  function readExtensionState() {
    return new Promise((resolve) => {
      chrome.storage.local.get(STORAGE_KEY, (result2) => {
        const saved = result2[STORAGE_KEY];
        const pointEvents = migrateLegacyPointEvents(saved?.pointEvents, saved?.points, "Previous extension demo balance");
        const manualCorrections = Object.fromEntries(Object.entries(saved?.manualCorrections ?? {}).map(([key, correction]) => {
          const legacy = correction;
          if (legacy.fulfilmentPackaging !== void 0 || legacy.manufacturerPackaging !== void 0 || typeof legacy.packaging !== "string") return [key, correction];
          const migrated = migrateLegacyPackaging(legacy.packaging);
          return [key, { ...correction, fulfilmentPackaging: migrated.fulfilment?.description ?? null, manufacturerPackaging: migrated.manufacturer?.description ?? null, legacyPackagingReview: migrated.legacy?.description ?? null }];
        }));
        resolve({
          ...DEFAULT_EXTENSION_STATE,
          ...saved,
          wishlist: Array.isArray(saved?.wishlist) ? saved.wishlist.map((item) => ({ ...item, packaging: migrateLegacyPackaging(item.packaging) })) : [],
          completedActions: Array.isArray(saved?.completedActions) ? saved.completedActions : [],
          activities: Array.isArray(saved?.activities) ? saved.activities : DEFAULT_EXTENSION_STATE.activities,
          schemaVersion: 5,
          pointEvents,
          leaderboardProfile: { ...DEFAULT_EXTENSION_STATE.leaderboardProfile, ...saved?.leaderboardProfile ?? {} },
          backendAccountId: saved?.backendAccountId ?? null,
          syncQueue: Array.isArray(saved?.syncQueue) ? saved.syncQueue : [],
          importedForAccounts: Array.isArray(saved?.importedForAccounts) ? saved.importedForAccounts : [],
          manualCorrections,
          preferences: {
            ...DEFAULT_EXTENSION_STATE.preferences,
            ...saved?.preferences ?? {}
          }
        });
      });
    });
  }
  function queueExtensionEvent(state, event) {
    if (!state.backendAccountId) return;
    const item = localEventToQueueItem(event, "extension-import", state.backendAccountId);
    if (!item || state.syncQueue.some((candidate) => candidate.accountId === state.backendAccountId && candidate.deduplicationKey === item.deduplicationKey)) return;
    item.id = `live:${event.deduplicationKey}`;
    item.source = "extension";
    state.syncQueue.unshift(item);
  }
  function writeExtensionState(state) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.set({ [STORAGE_KEY]: state }, () => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve();
      });
    });
  }

  // extension/src/content.ts
  var ROOT_ID = "ecomind-extension-root";
  var factorLabels = {
    materials: "Material impact",
    carbon: "Estimated carbon",
    recycled: "Recycled content",
    durability: "Durability and circularity",
    fulfilmentPackaging: "Fulfilment packaging",
    manufacturerPackaging: "Manufacturer packaging"
  };
  var knownMaterialOptions = [
    "Cotton",
    "Organic cotton",
    "Recycled cotton",
    "Polyester",
    "Recycled polyester",
    "Nylon",
    "Recycled nylon",
    "Elastane",
    "Linen",
    "Hemp",
    "Wool",
    "Recycled wool",
    "Viscose",
    "Modal",
    "Lyocell",
    "Acrylic",
    "Silk",
    "Leather"
  ];
  var analysisState = "ready";
  var analysisDetail = "Ready to analyse";
  var currentProduct = null;
  var currentAnalysis = null;
  var currentDiagnostics = null;
  var shadow = null;
  var initialSignature = "";
  var variationObserver = null;
  var escapeHtml = (value) => String(value ?? "").replace(
    /[&<>'"]/g,
    (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]
  );
  var formatMoney = (product) => product.price === null ? "Price not detected" : `${product.currency ?? ""} ${product.price.toFixed(2)}`.trim();
  var productKey = (product) => product.productId ? `${product.retailer}:${product.productId}` : `${product.retailer}:${product.url.split("#")[0]}`;
  var currentPageSignature = () => `${location.pathname}${location.search}|${document.querySelector("#productTitle,main h1,h1")?.textContent?.trim() ?? ""}|${document.querySelector("input#ASIN")?.value ?? ""}`;
  function notifyPopup(state, detail, analysis) {
    analysisState = state;
    analysisDetail = detail;
    chrome.runtime.sendMessage(
      {
        type: "ECOMIND_STATUS_UPDATE",
        state,
        detail,
        ...analysis ? {
          score: analysis.score,
          range: analysis.range,
          grade: analysis.grade,
          confidence: analysis.confidence,
          provisional: analysis.provisional,
          hasSufficientEvidence: analysis.hasSufficientEvidence,
          baseScore: analysis.baseScore,
          certificationAdjustment: analysis.certificationAdjustment
        } : {}
      },
      () => void chrome.runtime.lastError
    );
  }
  function mascotMarkup(state) {
    const mascot = mascotDetails(state.preferences.mascot);
    return `<span class="mascot" role="img" aria-label="EcoMind ${escapeHtml(mascot.label)}">${mascot.glyph}</span>`;
  }
  function displayAnalysisForRecord(record) {
    const result2 = calculateGreenScore(record);
    const factors = result2.breakdown.map((item) => ({
      key: item.key,
      label: item.label,
      weight: item.weight,
      result: item.score === null ? { status: "unknown", score: null, evidence: [] } : {
        status: "known",
        score: Math.round(item.score),
        evidence: []
      }
    }));
    return {
      score: result2.score,
      range: result2.range ? [result2.range.min, result2.range.max] : null,
      grade: result2.grade,
      confidence: record.confidenceLevel,
      factors,
      explanation: `${result2.explanation} Base environmental score: ${result2.baseScore}. Verified environmental certification adjustment: +${result2.certificationAdjustment}. Final Green Score: ${result2.score}.`,
      canScore: true,
      provisional: result2.provisional,
      hasSufficientEvidence: result2.knownWeight >= 0.35,
      baseScore: result2.baseScore,
      certificationAdjustment: result2.certificationAdjustment
    };
  }
  function displayAnalysis(product) {
    if (product.parserUsed === "threadly" && product.productId) {
      const record = PRODUCT_RECORDS.find(
        (item) => item.id === product.productId
      );
      if (record) return displayAnalysisForRecord(record);
    }
    const result2 = scoreRealProduct(product);
    return {
      score: result2.score,
      range: result2.range,
      grade: result2.grade,
      confidence: result2.confidence,
      factors: Object.keys(result2.factors).map((key) => ({
        key,
        label: factorLabels[key],
        result: result2.factors[key],
        weight: SCORE_WEIGHTS[key]
      })),
      explanation: `${result2.explanation} ${result2.baseScore === null ? "Base environmental score unavailable." : `Base environmental score: ${result2.baseScore}.`} ${result2.certificationAdjustment ? `Verified environmental certification adjustment: +${result2.certificationAdjustment}.` : "No verified environmental certification found; no points added or removed."}`,
      canScore: result2.canScore,
      provisional: true,
      hasSufficientEvidence: result2.canScore,
      baseScore: result2.baseScore,
      certificationAdjustment: result2.certificationAdjustment
    };
  }
  function trafficIcon(colour) {
    return colour === "green" ? "\u2713" : colour === "amber" ? "\u2212" : colour === "red" ? "!" : "?";
  }
  function trafficMarkup(analysis, compact = false) {
    const status = getTrafficLightStatus(
      analysis.score,
      analysis.hasSufficientEvidence
    );
    const accessible = trafficLightAccessibleText(
      status,
      analysis.score,
      analysis.provisional,
      analysis.confidence,
      analysis.range
    );
    return `<div class="traffic traffic--${status.colour}${compact ? " traffic--compact" : ""}" role="img" aria-label="${escapeHtml(accessible)}" title="${escapeHtml(status.shortExplanation)}"><span class="traffic-mark">${trafficIcon(status.colour)}</span><span><strong>${escapeHtml(formatTrafficLightScore(analysis.score, analysis.provisional, compact ? null : analysis.range))}${analysis.grade ? ` \xB7 ${escapeHtml(analysis.grade)}` : ""}</strong><b>${escapeHtml(status.label)}${analysis.provisional && analysis.score !== null ? " \xB7 Provisional" : ""}</b><small>${escapeHtml(analysis.confidence)} confidence</small></span></div>`;
  }
  function reliabilityLabel(sourceType) {
    if (sourceType === "json-ld" || sourceType === "amazon-selector")
      return "Verified page evidence";
    if (sourceType === "manual-user-input") return "User-provided";
    if (sourceType === "ecomind-estimate") return "EcoMind estimate";
    return "Page-text extraction";
  }
  function factorMarkup(item) {
    const factor = item.result;
    const value = factor.status === "unknown" ? "Not disclosed" : factor.status === "estimated" ? `~${factor.score}/100 \xB7 ${factor.range[0]}\u2013${factor.range[1]}` : `${factor.score}/100`;
    const evidence = factor.evidence.map((source) => `${source.sourceLabel}: ${source.value}`).join(" \xB7 ");
    return `<article class="factor"><strong>${escapeHtml(item.label)}</strong><b>${escapeHtml(value)}</b><p>${escapeHtml(evidence || (factor.status === "unknown" ? "No supporting evidence found on this page." : "Directly disclosed product evidence."))}</p><small>${Math.round(item.weight * 100)}% weight \xB7 ${factor.status}</small></article>`;
  }
  function extractedMarkup(product) {
    const evidenceRows = product.evidence.length ? product.evidence.map(
      (item) => `<li><div><strong>${escapeHtml(item.field)}</strong><span>${escapeHtml(item.value ?? "Not disclosed")}</span></div><em>${escapeHtml(reliabilityLabel(item.sourceType))} \xB7 ${escapeHtml(item.sourceLabel)} \xB7 ${escapeHtml(item.confidence)}${item.selector ? ` \xB7 ${escapeHtml(item.selector)}` : ""}</em></li>`
    ).join("") : "<li><div><strong>No automatic evidence</strong><span>Use the correction panel below.</span></div><em>Not disclosed</em></li>";
    const packageValue = (stage) => {
      const value = product.packaging[stage];
      return value ? `${value.description ?? value.material ?? "Packaging disclosed"} \xB7 ${value.sourceType === "retailer-policy" ? "Estimated from retailer policy" : value.sourceLabel} \xB7 ${value.confidence} confidence` : "Not disclosed";
    };
    const certifications = product.certifications.length ? product.certifications.map((item) => `<li><div><strong>${escapeHtml(item.certificationId === "oeko-tex-standard-100" ? "Chemical-safety certification" : item.affectsPeopleInformation ? "People certification" : item.affectsEnvironmentalScore ? "Environmental certification" : "Certification candidate")}</strong><span>${escapeHtml(item.displayedName)} \xB7 ${escapeHtml(item.status)}</span></div><em>${escapeHtml(item.rawClaim)}${item.certificationIdValue ? ` \xB7 label ${escapeHtml(item.certificationIdValue)}` : ""} \xB7 ${escapeHtml(item.sourceLabel)} \xB7 ${escapeHtml(item.confidence)} confidence${item.affectsEnvironmentalScore ? " \xB7 included after independent verification" : " \xB7 not included in environmental score"}</em></li>`).join("") : "<li><div><strong>Certification</strong><span>Not found</span></div><em>No points added or removed.</em></li>";
    const claims = product.sustainabilityClaims.map((claim) => `<li><div><strong>Unverified sustainability claim</strong><span>${escapeHtml(claim)}</span></div><em>0 certification points</em></li>`).join("");
    return `<details class="extraction"><summary>See what EcoMind extracted</summary><p class="extract-intro">Original page evidence stays beside every normalised value. Retailer policy and product-page evidence remain separate.</p><h4 class="extract-subhead">Materials and certifications</h4><ul class="evidence-list">${certifications}${claims}</ul><ul class="evidence-list">${evidenceRows}</ul><div class="normalised"><div><span>Materials</span><b>${escapeHtml(product.materials.map((item) => `${item.percentage ?? "?"}% ${item.name}`).join(", ") || "Not disclosed")}</b></div><div><span>Recycled content</span><b>${product.recycledContentPercentage === null ? "Not disclosed" : `${product.recycledContentPercentage}%`}</b></div><div><span>Fulfilment packaging \xB7 5%</span><b>${escapeHtml(packageValue("fulfilment"))}</b></div><div><span>Manufacturer packaging \xB7 5%</span><b>${escapeHtml(packageValue("manufacturer"))}</b></div><div><span>Weight</span><b>${product.weightGrams === null ? "Not disclosed" : `${Math.round(product.weightGrams)} g`}</b></div><div><span>Country of origin</span><b>${escapeHtml(product.countryOfOrigin ?? "Not disclosed")}</b></div><div><span>Care</span><b>${escapeHtml(product.careInstructions ?? "Not disclosed")}</b></div></div></details>`;
  }
  function manualMarkup(product) {
    const certificationFields = `<fieldset><legend>Certification evidence</legend><label>Exact wording<textarea name="certificationClaim" rows="2" placeholder="Paste the exact certification wording"></textarea></label><label>Certification URL or ID<input name="certificationSourceUrl" placeholder="URL or certification ID"></label><label><input type="checkbox" name="certificationAsSellerClaim"> Treat as seller claim only</label><label><input type="checkbox" name="certificationNotDisclosed"> Certification not disclosed</label><p>User-provided evidence is never automatically verified.</p></fieldset>`;
    return `<details class="manual"><summary>Help EcoMind complete this analysis</summary><form id="manualForm"><label>Product title<input name="title" value="${escapeHtml(product.title)}" autocomplete="off"></label><label>Material-composition text<textarea name="materialText" rows="3" placeholder="Example: 60% organic cotton, 40% recycled polyester"></textarea></label><div class="manual-grid"><label>Material<select name="material"><option value="">Select if useful</option>${knownMaterialOptions.map((item) => `<option>${item}</option>`).join("")}</select></label><label>Percentage<input name="materialPercentage" type="number" min="0" max="100" inputmode="decimal"></label><label>Recycled content %<input name="recycled" type="number" min="0" max="100" inputmode="decimal"></label></div>${certificationFields}<fieldset><legend>Packaging \u2014 provide each stage separately</legend><label>Fulfilment packaging<textarea name="fulfilmentPackaging" rows="2" placeholder="Delivery box, mailer, bag or reduced-packaging option"></textarea></label><label>Source or observation<input name="fulfilmentPackagingSource" placeholder="Shown beside delivery options"></label><label><input type="checkbox" name="fulfilmentPackagingUncertain"> This fulfilment information is uncertain</label><label>Manufacturer packaging<textarea name="manufacturerPackaging" rows="2" placeholder="Individual polybag, branded box or wrapping"></textarea></label><label>Source or observation<input name="manufacturerPackagingSource" placeholder="Shown in product details"></label><label><input type="checkbox" name="manufacturerPackagingUncertain"> This manufacturer information is uncertain</label></fieldset><fieldset><legend>Explicitly mark as not disclosed</legend><label><input type="checkbox" name="missingMaterials"> Materials</label><label><input type="checkbox" name="missingRecycled"> Recycled content</label><label><input type="checkbox" name="missingFulfilmentPackaging"> Fulfilment packaging</label><label><input type="checkbox" name="missingManufacturerPackaging"> Manufacturer packaging</label></fieldset><label class="save-correction"><input type="checkbox" name="remember"> Save these corrections for this product only</label><button type="submit">Re-run provisional score</button><p>Manual values are labelled \u201CUser-provided\u201D and never represented as retailer evidence. EcoMind does not open checkout automatically.</p></form></details>`;
  }
  function comparisonMarkup(state, product) {
    const packagingRows = (packaging) => `<small><b>Fulfilment \xB7 5%:</b> ${escapeHtml(packagingEvidenceLabel(packaging?.fulfilment ?? null))}</small><small><b>Manufacturer \xB7 5%:</b> ${escapeHtml(packagingEvidenceLabel(packaging?.manufacturer ?? null))}</small>`;
    if (product.parserUsed === "threadly") {
      const record = PRODUCT_RECORDS.find(
        (item) => item.id === product.productId
      );
      const alternative = PRODUCT_RECORDS.find(
        (item) => item.id === record?.alternativeProductId
      );
      if (!alternative)
        return '<section class="guidance"><h3>General improvement guidance</h3><p>Repair, reuse, buy second-hand or look for stronger disclosed evidence before purchasing.</p></section>';
      const alternativeAnalysis = displayAnalysisForRecord(alternative);
      return `<section class="guidance"><span>THREADLY DEMO ALTERNATIVE</span><h3>${escapeHtml(alternative.productName)}</h3><p>This fictional option remains available only in the controlled Threadly demo. It is never presented as a real retailer listing.</p><div class="demo-alternative">${trafficMarkup(alternativeAnalysis, true)}<small>\xA3${alternative.price.toFixed(2)} \xB7 ${alternative.recycledContentPercentage ?? 0}% recycled content</small><small>${escapeHtml(alternative.tradeOff)}</small></div><div class="guidance-actions"><button class="compare-threadly" type="button">Record demo comparison</button><button class="save-threadly" type="button">Save demo alternative</button></div></section>`;
    }
    const previous = [...state.wishlist].reverse().find(
      (item) => item.url && item.id !== productKey(product) && item.materials?.length
    );
    if (!previous)
      return '<section class="guidance"><h3>Compare real evidence, not fictional products</h3><p>Save this product for comparison, open another clothing product on any supported store, then analyse it. EcoMind stores only the extracted comparison fields\u2014not the webpage.</p></section>';
    const previousStatus = getTrafficLightStatus(
      previous.score,
      previous.score !== null
    );
    const previousAccessible = trafficLightAccessibleText(
      previousStatus,
      previous.score,
      true,
      previous.confidenceLevel
    );
    return `<section class="real-compare"><span>PREVIOUSLY ANALYSED PRODUCT</span><h3>Compare across retailers</h3><div class="compare-grid"><div><b>${escapeHtml(product.title)}</b><small>${escapeHtml(product.retailer)}</small>${currentAnalysis ? trafficMarkup(currentAnalysis, true) : ""}<div class="compare-packaging">${packagingRows(product.packaging)}</div></div><div><b>${escapeHtml(previous.productName)}</b><small>${escapeHtml(previous.retailer ?? "Previous retailer")}</small><div class="traffic traffic--${previousStatus.colour} traffic--compact" role="img" aria-label="${escapeHtml(previousAccessible)}" title="${escapeHtml(previousStatus.shortExplanation)}"><span class="traffic-mark">${trafficIcon(previousStatus.colour)}</span><span><strong>${escapeHtml(formatTrafficLightScore(previous.score, true, null))}${previous.grade ? ` \xB7 ${escapeHtml(previous.grade)}` : ""}</strong><b>${escapeHtml(previousStatus.label)} \xB7 Provisional</b><small>${escapeHtml(previous.confidenceLevel)} confidence</small></span></div><div class="compare-packaging">${packagingRows(previous.packaging)}</div></div></div><button class="compare-previous" type="button" data-previous="${escapeHtml(previous.id)}">Record real-product comparison</button></section>`;
  }
  var styles = `:host{all:initial;font-family:"Segoe UI",system-ui,sans-serif;color:#102a2c}*{box-sizing:border-box}button,input,textarea,select{font:inherit}button:focus-visible,summary:focus-visible,input:focus-visible,textarea:focus-visible,select:focus-visible{outline:3px solid rgba(22,115,77,.34);outline-offset:2px}.widget{position:fixed;z-index:2147483600;right:22px;bottom:22px;min-width:300px;min-height:76px;padding:9px 13px 9px 9px;display:flex;align-items:center;gap:11px;border:0;border-radius:16px;background:#102f30;color:#f5fff9;box-shadow:0 8px 24px rgba(8,35,31,.3);cursor:pointer;text-align:left}.widget .copy{display:flex;flex:1;flex-direction:column}.widget .copy strong{font-size:13px}.widget .copy small{font-size:10px;color:#abc8bb}.widget .score{min-width:58px;padding-right:10px;border-right:1px solid rgba(255,255,255,.2)}.widget .score strong{font-size:20px}.widget .score small{font-size:9px;color:#aac5ba}.widget .score b{display:block;margin-top:2px;color:#8edcaf;font-size:9px}.koala{position:relative;width:54px;height:54px;display:inline-block;flex:none}.koala .face{position:absolute;z-index:2;inset:9px 6px 2px;border-radius:48%;background:#a9b6b1;border:1px solid #657773}.koala .ear{position:absolute;z-index:1;top:6px;width:20px;height:23px;border-radius:50%;background:#879995;border:1px solid #657773;box-shadow:inset 0 0 0 5px #c8d0cd}.koala .ear.left{left:0}.koala .ear.right{right:0}.koala .eye{position:absolute;top:18px;width:5px;height:6px;border-radius:50%;background:#172d2d}.koala .eye.left{left:11px}.koala .eye.right{right:11px}.koala .nose{position:absolute;top:24px;left:50%;width:12px;height:14px;transform:translateX(-50%);border-radius:45%;background:#243a39}.koala .leaf{position:absolute;z-index:4;right:0;top:0;width:15px;height:10px;border-radius:80% 10%;transform:rotate(-24deg);background:#16734d}.layer{position:fixed;z-index:2147483601;inset:0;background:rgba(9,30,29,.5);opacity:0;pointer-events:none}.layer.open{opacity:1;pointer-events:auto}.drawer{position:absolute;right:0;top:0;width:min(100%,620px);height:100%;display:flex;flex-direction:column;background:#f5f8f6;box-shadow:-8px 0 24px rgba(8,35,31,.22);transform:translateX(100%);transition:transform .22s cubic-bezier(.16,1,.3,1)}.layer.open .drawer{transform:none}.drawer-header{height:68px;padding:0 20px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #d9e3dd;background:#fff}.drawer-header div{display:flex;flex-direction:column}.drawer-header span{font-size:9px;color:#60736e}.close{width:40px;height:40px;border:1px solid #d4dfd8;border-radius:11px;background:#fff;font-size:22px}.drawer-body{flex:1;overflow:auto;padding:20px 20px 94px}.product{display:flex;gap:13px;align-items:center}.product img{width:72px;height:72px;border-radius:11px;object-fit:cover}.product span,.meta-row{font-size:9px;color:#647873}.product h2{margin:3px 0;font-size:18px;line-height:1.2}.product b{font-size:12px}.meta-row{margin-top:10px;display:flex;flex-wrap:wrap;gap:5px}.meta-row span{padding:5px 7px;border-radius:7px;background:#e8efeb}.score-hero{margin-top:16px;padding:17px;display:grid;grid-template-columns:auto 1fr;gap:16px;border-radius:14px;background:#fff3dc}.big-score strong{font-size:43px}.big-score small{font-size:10px}.big-score b{display:block;width:28px;padding:4px;border-radius:6px;background:#9a5437;color:#fff;text-align:center}.score-copy h3{margin:2px 0 5px;font-size:14px}.score-copy p{margin:0;font-size:10px;line-height:1.45;color:#60716e}.local-note{margin-top:9px;padding:10px 11px;border-radius:10px;background:#f0edf7;color:#63567b;font-size:10px;line-height:1.45}.section{margin-top:22px}.section h3{margin:0 0 9px;font-size:14px}.breakdown{display:grid;gap:6px}.factor{padding:11px 12px;display:grid;grid-template-columns:1fr auto;gap:4px;border:1px solid #d9e3dd;border-radius:11px;background:#fff}.factor strong,.factor b{font-size:11px}.factor p{grid-column:1/span 2;margin:0;color:#687976;font-size:9px;line-height:1.4}.factor small{grid-column:1/span 2;color:#81908b;font-size:8px}details{margin-top:15px;border:1px solid #d9e3dd;border-radius:11px;background:#fff}summary{padding:12px;font-size:11px;font-weight:750;cursor:pointer}.extract-intro,details>p{margin:0;padding:0 12px 12px;color:#60716e;font-size:9px;line-height:1.5}.evidence-list{margin:0;padding:0 12px 10px;list-style:none}.evidence-list li{padding:8px 0;border-top:1px solid #e4eae6}.evidence-list div{display:flex;justify-content:space-between;gap:10px;font-size:9px}.evidence-list em{display:block;margin-top:3px;color:#72827e;font-size:8px;font-style:normal}.normalised{padding:0 12px 12px;display:grid;grid-template-columns:1fr 1fr;gap:6px}.normalised div{padding:8px;border-radius:8px;background:#edf4f0}.normalised span{display:block;color:#71817e;font-size:8px}.normalised b{font-size:9px}.missing{margin-top:16px;padding:12px;border-radius:11px;background:#fff3df}.missing h3{margin:0;font-size:12px}.missing ul{margin:7px 0 0;padding-left:17px;font-size:9px}.missing p{margin:7px 0 0;font-size:9px;color:#76532e}.manual form{padding:0 12px 12px}.manual label{display:grid;gap:4px;margin-top:8px;color:#536a64;font-size:9px}.manual input,.manual textarea,.manual select{width:100%;padding:8px;border:1px solid #bdcbc4;border-radius:8px;background:#fff;color:#17322e;font-size:10px}.manual-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.manual fieldset{margin-top:9px;padding:8px;border:1px solid #d9e3dd;border-radius:8px}.manual fieldset label,.save-correction{display:flex!important;align-items:center;gap:6px}.manual input[type="checkbox"]{width:auto}.manual button,.compare-previous,.guidance-actions button{width:100%;min-height:40px;margin-top:10px;border:0;border-radius:9px;background:#16734d;color:#fff;font-size:10px;font-weight:750}.manual form p{margin:7px 0 0;color:#71817e;font-size:8px}.guidance,.real-compare{margin-top:19px;padding:14px;border-radius:13px;background:#102f30;color:#fff}.guidance span,.real-compare>span{color:#8edcaf;font-size:8px}.guidance h3,.real-compare h3{margin:4px 0 6px;font-size:13px}.guidance p{margin:0;color:#b7cdc3;font-size:9px;line-height:1.45}.demo-alternative{margin-top:10px;padding:10px;border-radius:8px;background:rgba(255,255,255,.08)}.demo-alternative b,.demo-alternative small{display:block}.demo-alternative b{color:#8edcaf;font-size:12px}.demo-alternative small{margin-top:3px;color:#b7cdc3;font-size:9px}.guidance-actions{display:grid;grid-template-columns:1fr 1fr;gap:7px}.guidance-actions .save-threadly{background:#edf7f1;color:#124b38}.compare-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.compare-grid div{padding:9px;border-radius:8px;background:rgba(255,255,255,.08)}.compare-grid b,.compare-grid small,.compare-grid strong{display:block;font-size:9px}.compare-grid small{color:#b7cdc3}.compare-grid strong{margin-top:5px;color:#8edcaf}.diagnostics{font-family:ui-monospace,monospace}.diagnostics pre{margin:0;padding:0 12px 12px;white-space:pre-wrap;word-break:break-word;font-size:8px}.disclaimer{margin:16px 0 0;color:#72827e;font-size:9px;line-height:1.5;text-align:center}.drawer-footer{position:absolute;left:0;right:0;bottom:0;padding:12px 20px;border-top:1px solid #d9e3dd;background:#fff}.drawer-footer button{width:100%;min-height:44px;border:0;border-radius:10px;background:#16734d;color:#fff;font-weight:750}.toast{position:fixed;z-index:2147483602;right:22px;bottom:110px;max-width:330px;padding:12px;border-radius:10px;background:#173b32;color:#fff;font-size:10px}@media(max-width:620px){.widget{right:10px;left:10px;bottom:10px}.drawer{width:100%}.drawer-body{padding-inline:13px}.score-hero{grid-template-columns:1fr}.normalised,.manual-grid,.guidance-actions{grid-template-columns:1fr}.drawer-footer{padding-inline:13px}}@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}`;
  var trafficStyles = `.traffic{display:flex;align-items:center;gap:9px;min-width:180px}.traffic>span:last-child{display:flex;flex-direction:column}.traffic strong{font-size:14px;line-height:1.15}.traffic b{margin-top:2px;font-size:10px}.traffic small{margin-top:2px;font-size:9px;color:#60736e}.traffic-mark{width:30px;height:30px;display:grid;place-items:center;flex:none;border-radius:50%;font-size:17px;font-weight:900}.traffic--green .traffic-mark{background:#176b45;color:#fff}.traffic--amber .traffic-mark{border-radius:7px;background:#a66a00;color:#fff}.traffic--red .traffic-mark{background:#a33c32;color:#fff}.traffic--grey .traffic-mark{border:2px solid #65736f;background:#fff;color:#394b47}.traffic--green b{color:#176b45}.traffic--amber b{color:#805500}.traffic--red b{color:#96352d}.traffic--grey b{color:#53635f}.traffic--compact{min-width:150px;gap:7px}.traffic--compact .traffic-mark{width:24px;height:24px;font-size:13px}.traffic--compact strong{font-size:11px}.traffic--compact b,.traffic--compact small{font-size:8px}.widget>.traffic{color:#fff}.widget>.traffic small{color:#abc8bb}.widget>.traffic b{color:#fff}.score-hero>.traffic{align-self:start}.score-hero>.traffic strong{font-size:22px}.traffic-legend ul{margin:0;padding:0 12px 10px;display:grid;gap:6px;list-style:none}.traffic-legend li{display:flex;align-items:center;gap:7px;font-size:9px}.traffic-legend i{width:20px;height:20px;display:grid;place-items:center;border-radius:50%;color:#fff;font-style:normal;font-weight:900}.traffic-legend i.green{background:#176b45}.traffic-legend i.amber{border-radius:6px;background:#a66a00}.traffic-legend i.red{background:#a33c32}.traffic-legend i.grey{border:2px solid #65736f;background:#fff;color:#394b47}.traffic-legend p{padding:0 12px 12px}.compare-grid .traffic{margin-top:7px}`;
  var brightTrafficStyles = `.traffic--green .traffic-mark,.traffic-legend i.green{background:#22c55e;color:#123d24}.traffic--amber .traffic-mark,.traffic-legend i.amber{background:#f59e0b;color:#3d2600}.traffic--amber b{color:#854d0e}.traffic--red .traffic-mark,.traffic-legend i.red{background:#ef4444}.extract-subhead{margin:0;padding:0 12px 8px;font-size:10px}.compare-packaging{margin-top:7px}.compare-packaging small{margin-top:4px}`;
  var mentorStyles = `.widget{min-width:0;min-height:52px;padding:7px 11px 7px 7px;gap:8px;border:1px solid rgba(255,255,255,.18);border-radius:26px;box-shadow:0 5px 16px rgba(8,35,31,.22)}.widget .mascot{width:36px;height:36px;display:grid;place-items:center;flex:none;border-radius:50%;background:rgba(255,255,255,.1);font-size:21px;filter:saturate(.75)}.widget>.traffic{min-width:0}.widget>.traffic .traffic-mark{width:26px;height:26px}.widget>.traffic span:last-child{min-width:92px}.widget>.traffic strong{font-size:11px}.widget>.traffic b{font-size:8px}.widget>.traffic small{display:none}.widget .copy{display:none}.drawer-header__actions{display:flex;gap:7px}.drawer-header__actions button{height:38px;padding:0 11px;border:1px solid #d4dfd8;border-radius:10px;background:#fff;color:#28453e;font-size:10px;font-weight:750}.drawer-header__actions .close{width:38px;padding:0;font-size:20px}.companion-panel{margin-top:15px;padding:12px;border:1px solid #d9e3dd;border-radius:11px;background:#fff}.companion-panel h3{margin:0;font-size:12px}.companion-panel p{margin:4px 0 10px;color:#667873;font-size:9px}.mascot-options{display:grid;grid-template-columns:repeat(5,1fr);gap:5px}.mascot-option{min-height:47px;padding:5px;border:1px solid #d8e2dc;border-radius:9px;background:#f7f9f8;color:#435a54;font-size:18px}.mascot-option span{display:block;margin-top:2px;font-size:7px}.mascot-option[aria-pressed=true]{border-color:#16734d;background:#e7f5ec;color:#0c5a3a}.widget-preference{margin-top:9px;display:flex;align-items:flex-start;gap:7px;color:#536a64;font-size:9px}.widget-preference input{margin-top:1px;accent-color:#16734d}.emotional-note{display:flex;align-items:center;gap:8px}.emotional-note .mascot{font-size:18px}@media(max-width:620px){.widget{right:10px;left:auto;bottom:10px}.widget>.traffic span:last-child{min-width:86px}.mascot-options{grid-template-columns:repeat(3,1fr)}}`;
  function renderExtension(product, analysis, state, diagnostics) {
    document.getElementById(ROOT_ID)?.remove();
    const host = document.createElement("div");
    host.id = ROOT_ID;
    host.setAttribute("aria-label", "EcoMind AI extension analysis");
    document.documentElement.appendChild(host);
    shadow = host.attachShadow({ mode: "open" });
    const status = getTrafficLightStatus(
      analysis.score,
      analysis.hasSufficientEvidence
    );
    const rangeLabel = analysis.range ? `${analysis.range[0]}\u2013${analysis.range[1]}/100 possible range` : "Not enough evidence for a range";
    const missing = product.missingFields.length ? product.missingFields.map((field) => `<li>${escapeHtml(field)}: Not disclosed</li>`).join("") : "<li>No major fields missing.</li>";
    const debugEnabled = new URLSearchParams(location.search).get("ecomind-debug") === "true" || state.preferences.diagnosticsEnabled;
    const diagnosticsMarkup = debugEnabled ? `<details class="diagnostics"><summary>Developer diagnostics</summary><pre>${escapeHtml(JSON.stringify({ ...diagnostics, finalConfidence: analysis.confidence, scoringInputs: analysis.factors }, null, 2))}</pre></details>` : "";
    const selectedMascot = mascotDetails(state.preferences.mascot);
    const mascotOptions = ["koala", "panda", "polar-bear", "leaf", "sprout"].map((id) => {
      const option = mascotDetails(id);
      return `<button class="mascot-option" type="button" data-mascot="${option.id}" aria-pressed="${option.id === selectedMascot.id}">${option.glyph}<span>${escapeHtml(option.label)}</span></button>`;
    }).join("");
    shadow.innerHTML = `<style>${styles}</style><button class="widget" type="button" aria-label="${escapeHtml(trafficLightAccessibleText(status, analysis.score, analysis.provisional, analysis.confidence, analysis.range))} Open EcoMind analysis.">${mascotMarkup(state)}${trafficMarkup(analysis, true)}<span class="copy"><strong>${escapeHtml(status.label)}</strong><small>${escapeHtml(analysis.confidence)} confidence \xB7 Open analysis</small></span></button><div class="layer" role="presentation"><aside class="drawer" role="dialog" aria-modal="true" aria-labelledby="ecomind-title"><header class="drawer-header"><div><strong>EcoMind analysis</strong><span>Local \xB7 ${escapeHtml(product.retailer)} \xB7 ${escapeHtml(product.parserUsed)}</span></div><div class="drawer-header__actions"><button class="hide-widget" type="button">Hide on this page</button><button class="close" type="button" aria-label="Minimise EcoMind analysis">\u2212</button></div></header><div class="drawer-body"><section class="product">${product.imageUrl ? `<img src="${escapeHtml(product.imageUrl)}" alt="${escapeHtml(product.title ?? "Product image")}">` : ""}<div><span>${escapeHtml(product.retailer)}</span><h2 id="ecomind-title">${escapeHtml(product.title ?? "Product information needed")}</h2><b>${escapeHtml(formatMoney(product))}</b></div></section><div class="meta-row"><span>Parser: ${escapeHtml(product.parserUsed)}</span><span>${escapeHtml(product.url)}</span><span>${analysis.factors.filter((item) => item.result.status !== "unknown").length}/5 factors supported</span></div><section class="score-hero">${trafficMarkup(analysis)}<div class="score-copy"><h3>${escapeHtml(analysis.explanation)}</h3><p>${escapeHtml(rangeLabel)}. Missing evidence is unknown, never confirmed zero.</p></div></section><details class="traffic-legend"><summary>How to read the traffic light</summary><ul><li><i class="green">\u2713</i> Green: Lower impact based on available evidence</li><li><i class="amber">\u2212</i> Amber: Mixed environmental impact</li><li><i class="red">!</i> Red: Higher impact</li><li><i class="grey">?</i> Grey: Not enough information</li></ul><p>Product status only. A green result is not a certification and leaderboard positions never use these colours.</p></details><div class="local-note"><strong>Local evidence analysis.</strong> EcoMind structures product information from this active page. The deterministic prototype formula\u2014not AI\u2014calculates the provisional midpoint and range.</div>${extractedMarkup(product)}<section class="section"><h3>Score breakdown</h3><div class="breakdown">${analysis.factors.map(factorMarkup).join("")}</div></section><section class="missing"><h3>Missing information</h3><ul>${missing}</ul><p>Absence of disclosure does not prove poor performance. It lowers confidence and widens the range.</p></section>${manualMarkup(product)}${comparisonMarkup(state, product)}<section class="companion-panel"><h3>${selectedMascot.glyph} Your EcoMind companion</h3><p>Choose a calm visual cue. This preference stays on this device.</p><div class="mascot-options">${mascotOptions}</div><label class="widget-preference"><input class="auto-widget" type="checkbox" ${state.preferences.showWidgetAfterAnalysis ? "checked" : ""}> Show the minimised widget automatically after analysis</label></section>${diagnosticsMarkup}<p class="disclaimer">Provisional scores are estimates, not certifications. Retail pages can be incomplete or change without notice. EcoMind sends no product information to a server.</p></div><footer class="drawer-footer"><button class="save" type="button">Save for comparison</button></footer></aside></div>`;
    const factorCount = shadow.querySelector(".meta-row span:last-child");
    if (factorCount) factorCount.textContent = `${analysis.factors.filter((item) => item.result.status !== "unknown").length}/6 factors supported`;
    const widgetSummary = shadow.querySelector(".widget .copy small");
    if (widgetSummary) widgetSummary.textContent = `${analysis.confidence} confidence \xB7 Packaging 5% + 5% \xB7 Open analysis`;
    const trafficStyle = document.createElement("style");
    trafficStyle.textContent = trafficStyles + brightTrafficStyles + mentorStyles;
    shadow.prepend(trafficStyle);
    const layer = shadow.querySelector(".layer");
    const widget = shadow.querySelector(".widget");
    const close = shadow.querySelector(".close");
    const openDrawer = () => {
      host.hidden = false;
      layer.classList.add("open");
      document.body.inert = true;
      close.focus();
    };
    const closeDrawer = () => {
      layer.classList.remove("open");
      document.body.inert = false;
      widget.focus();
    };
    widget.addEventListener("click", openDrawer);
    close.addEventListener("click", closeDrawer);
    shadow.querySelector(".hide-widget")?.addEventListener("click", () => {
      closeDrawer();
      host.hidden = true;
      showToast("Widget hidden on this page. Use the EcoMind toolbar button to bring it back.");
    });
    layer.addEventListener("click", (event) => {
      if (event.target === layer) closeDrawer();
    });
    shadow.addEventListener("keydown", (event) => {
      if (!(event instanceof KeyboardEvent) || !layer.classList.contains("open"))
        return;
      if (event.key === "Escape") {
        closeDrawer();
        return;
      }
      if (event.key !== "Tab") return;
      const focusable = [
        ...shadow.querySelectorAll(
          "button:not([disabled]),summary,input:not([disabled]),textarea:not([disabled]),select:not([disabled])"
        )
      ];
      const first = focusable[0];
      const last = focusable.at(-1);
      if (!first || !last) return;
      if (event.shiftKey && shadow.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && shadow.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });
    shadow.querySelector(".save").addEventListener("click", () => void saveForComparison(product, analysis));
    shadow.querySelector(".compare-previous")?.addEventListener("click", () => void recordRealComparison(product));
    shadow.querySelector(".compare-threadly")?.addEventListener("click", () => void recordThreadlyComparison(product));
    shadow.querySelector(".save-threadly")?.addEventListener("click", () => void saveThreadlyAlternative(product));
    shadow.querySelector("#manualForm").addEventListener(
      "submit",
      (event) => void submitManualCorrection(event, product)
    );
    shadow.querySelectorAll(".mascot-option").forEach((button) => button.addEventListener("click", async () => {
      const next = await readExtensionState();
      next.preferences.mascot = button.dataset.mascot;
      await writeExtensionState(next);
      renderExtension(product, analysis, next, diagnostics);
      showToast(`${mascotDetails(next.preferences.mascot).glyph} Companion updated. Small choice, meaningful impact.`);
    }));
    shadow.querySelector(".auto-widget")?.addEventListener("change", async (event) => {
      const checked = event.currentTarget.checked;
      const next = await readExtensionState();
      next.preferences.showWidgetAfterAnalysis = checked;
      await writeExtensionState(next);
      if (!next.preferences.showWidgetAfterAnalysis) {
        closeDrawer();
        host.hidden = true;
      }
    });
    host.hidden = !state.preferences.showWidgetAfterAnalysis;
  }
  function showToast(message) {
    shadow?.querySelector(".toast")?.remove();
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.setAttribute("role", "status");
    toast.textContent = message;
    shadow?.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
  }
  function wishlistItem(product, analysis) {
    return {
      id: productKey(product),
      productName: product.title ?? "Untitled product",
      price: product.price,
      currency: product.currency,
      score: analysis.score,
      scoreRange: analysis.range,
      grade: analysis.grade,
      confidenceLevel: analysis.confidence,
      alternativeAvailable: false,
      retailer: product.retailer,
      url: product.url,
      parserUsed: product.parserUsed,
      materials: product.materials,
      recycledContentPercentage: product.recycledContentPercentage,
      packaging: product.packaging,
      certifications: product.certifications,
      sustainabilityClaims: product.sustainabilityClaims
    };
  }
  async function saveForComparison(product, analysis) {
    const state = await readExtensionState();
    const item = wishlistItem(product, analysis);
    const index = state.wishlist.findIndex((saved) => saved.id === item.id);
    if (index >= 0) state.wishlist[index] = item;
    else state.wishlist.push(item);
    await writeExtensionState(state);
    showToast(
      index >= 0 ? "Saved comparison record updated." : "Extracted fields saved for real-product comparison."
    );
  }
  async function recordRealComparison(product) {
    const state = await readExtensionState();
    const key = `real-compare-${productKey(product)}`;
    if (!state.completedActions.includes(key)) {
      const event = createPointEvent({
        actionType: "compareGreenerAlternative",
        points: ECO_POINT_RULES.compareGreenerAlternative,
        source: "extension",
        deduplicationKey: key,
        title: "Real products compared",
        detail: product.title ?? product.retailer,
        selfReported: false
      });
      state.pointEvents = addPointEvent(state.pointEvents, event);
      queueExtensionEvent(state, event);
      state.completedActions.push(key);
      state.points += event.points;
      state.activities.unshift({
        id: event.id,
        title: event.title,
        detail: event.detail,
        points: event.points,
        date: "Today",
        timestamp: event.timestamp
      });
      await writeExtensionState(state);
      showToast(
        state.backendAccountId ? `${mascotDetails(state.preferences.mascot).glyph} Your choice supports more sustainable consumption. Comparison is waiting for backend confirmation.` : `${mascotDetails(state.preferences.mascot).glyph} Your choice supports more sustainable consumption. Comparison recorded locally. +5 EcoPoints.`
      );
    } else showToast("This comparison is already recorded.");
  }
  async function recordThreadlyComparison(product) {
    const record = PRODUCT_RECORDS.find((item) => item.id === product.productId);
    const alternative = PRODUCT_RECORDS.find(
      (item) => item.id === record?.alternativeProductId
    );
    if (!record || !alternative) return;
    const state = await readExtensionState();
    const key = `compare-${record.id}`;
    if (!state.completedActions.includes(key)) {
      const event = createPointEvent({
        actionType: "compareGreenerAlternative",
        points: ECO_POINT_RULES.compareGreenerAlternative,
        source: "extension",
        deduplicationKey: key,
        title: "Greener demo alternative compared",
        detail: alternative.productName,
        selfReported: false
      });
      state.pointEvents = addPointEvent(state.pointEvents, event);
      queueExtensionEvent(state, event);
      state.completedActions.push(key);
      state.points += event.points;
      state.activities.unshift({
        id: event.id,
        title: event.title,
        detail: event.detail,
        points: event.points,
        date: "Today",
        timestamp: event.timestamp
      });
      await writeExtensionState(state);
      showToast(
        state.backendAccountId ? `${mascotDetails(state.preferences.mascot).glyph} Small choice, meaningful impact. Comparison is waiting for backend confirmation.` : `${mascotDetails(state.preferences.mascot).glyph} Small choice, meaningful impact. Demo comparison recorded locally. +5 EcoPoints.`
      );
    } else showToast("This demo comparison is already recorded.");
  }
  async function saveThreadlyAlternative(product) {
    const record = PRODUCT_RECORDS.find((item2) => item2.id === product.productId);
    const alternative = PRODUCT_RECORDS.find(
      (item2) => item2.id === record?.alternativeProductId
    );
    if (!alternative) return;
    const result2 = calculateGreenScore(alternative);
    const state = await readExtensionState();
    const id = `Threadly demo:${alternative.id}`;
    const key = `save-${alternative.id}`;
    const item = {
      id,
      productName: alternative.productName,
      price: alternative.price,
      currency: alternative.currency,
      score: result2.score,
      scoreRange: result2.range ? [result2.range.min, result2.range.max] : null,
      grade: result2.grade,
      confidenceLevel: alternative.confidenceLevel,
      alternativeAvailable: false,
      retailer: "Threadly demo",
      url: `${location.origin}${location.pathname}#/demo`,
      parserUsed: "threadly",
      materials: alternative.materials.map((material) => ({
        name: material.material,
        percentage: material.percentage,
        evidence: alternative.listingText
      })),
      recycledContentPercentage: alternative.recycledContentPercentage,
      packaging: alternative.packaging,
      certifications: alternative.certifications,
      sustainabilityClaims: alternative.sustainabilityClaims
    };
    const index = state.wishlist.findIndex((saved) => saved.id === id);
    if (index >= 0) state.wishlist[index] = item;
    else state.wishlist.push(item);
    if (!state.completedActions.includes(key)) {
      const event = createPointEvent({
        actionType: "saveLowerImpactOption",
        points: ECO_POINT_RULES.saveLowerImpactOption,
        source: "extension",
        deduplicationKey: key,
        title: "Demo alternative saved",
        detail: alternative.productName,
        selfReported: false
      });
      state.pointEvents = addPointEvent(state.pointEvents, event);
      queueExtensionEvent(state, event);
      state.completedActions.push(key);
      state.points += event.points;
      state.activities.unshift({
        id: event.id,
        title: event.title,
        detail: event.detail,
        points: event.points,
        date: "Today",
        timestamp: event.timestamp
      });
    }
    await writeExtensionState(state);
    showToast(
      index >= 0 ? `${mascotDetails(state.preferences.mascot).glyph} Lower-impact demo option updated.` : `${mascotDetails(state.preferences.mascot).glyph} Thank you for choosing a lower-impact option. Saved locally. +5 demo EcoPoints.`
    );
  }
  async function submitManualCorrection(event, product) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const materialText = [
      String(data.get("materialText") ?? "").trim(),
      data.get("material") && data.get("materialPercentage") ? `${data.get("materialPercentage")}% ${data.get("material")}` : ""
    ].filter(Boolean).join(", ");
    const missing = [
      data.get("missingMaterials") ? "materials" : null,
      data.get("missingRecycled") ? "recycledContent" : null,
      data.get("missingFulfilmentPackaging") ? "fulfilmentPackaging" : null,
      data.get("missingManufacturerPackaging") ? "manufacturerPackaging" : null
    ].filter(
      (item) => item !== null
    );
    const corrections = {
      title: String(data.get("title") ?? "").trim() || null,
      materialText: materialText || null,
      recycledContentPercentage: data.get("recycled") ? Number(data.get("recycled")) : null,
      fulfilmentPackaging: String(data.get("fulfilmentPackaging") ?? "").trim() || null,
      manufacturerPackaging: String(data.get("manufacturerPackaging") ?? "").trim() || null,
      fulfilmentPackagingSource: String(data.get("fulfilmentPackagingSource") ?? "").trim() || null,
      manufacturerPackagingSource: String(data.get("manufacturerPackagingSource") ?? "").trim() || null,
      fulfilmentPackagingUncertain: Boolean(
        data.get("fulfilmentPackagingUncertain")
      ),
      manufacturerPackagingUncertain: Boolean(
        data.get("manufacturerPackagingUncertain")
      ),
      certificationClaim: String(data.get("certificationClaim") ?? "").trim() || null,
      certificationSourceUrl: String(data.get("certificationSourceUrl") ?? "").trim() || null,
      certificationAsSellerClaim: Boolean(data.get("certificationAsSellerClaim")),
      certificationNotDisclosed: Boolean(data.get("certificationNotDisclosed")),
      markNotDisclosed: missing
    };
    currentProduct = applyManualCorrections(product, corrections);
    currentAnalysis = displayAnalysis(currentProduct);
    const state = await readExtensionState();
    if (data.get("remember")) {
      state.manualCorrections[productKey(product)] = corrections;
      await writeExtensionState(state);
    }
    renderExtension(
      currentProduct,
      currentAnalysis,
      state,
      currentDiagnostics ?? parseProductPage(document, location.href).diagnostics
    );
    showToast("Manual evidence applied and labelled \u201CProvided by user\u201D.");
    notifyPopup(
      currentAnalysis.canScore ? currentAnalysis.confidence === "Low" ? "low-confidence" : "missing-data" : currentProduct.isClothing ? "missing-data" : "unsupported-category",
      "Manual evidence applied locally. Open EcoMind to review the revised result.",
      currentAnalysis
    );
  }
  function recordAnalysis(state, product) {
    const key = `analysis-${productKey(product)}`;
    if (state.completedActions.includes(key)) return;
    const event = createPointEvent({
      actionType: "analysis",
      points: 0,
      source: "extension",
      deduplicationKey: key,
      title: "Product analysis completed",
      detail: `${product.retailer}: ${product.title ?? "manual entry"}`,
      selfReported: false
    });
    state.pointEvents = addPointEvent(state.pointEvents, event);
    state.completedActions.push(key);
    state.activities.unshift({
      id: event.id,
      title: event.title,
      detail: event.detail,
      points: 0,
      date: "Today",
      timestamp: event.timestamp
    });
  }
  function installVariationWatch(product) {
    variationObserver?.disconnect();
    initialSignature = currentPageSignature();
    const targets = [
      document.querySelector("#productTitle"),
      document.querySelector("input#ASIN"),
      document.querySelector("#variation_color_name"),
      document.querySelector("#variation_size_name"),
      document.querySelector("main h1")
    ].filter((item) => Boolean(item));
    if (!targets.length || product.parserUsed === "threadly") return;
    const check = () => {
      if (currentPageSignature() !== initialSignature && analysisState !== "product-changed") {
        notifyPopup(
          "product-changed",
          "The product title, identifier or selected variation changed. Re-analyse this product."
        );
        shadow?.querySelector(".widget .copy strong")?.replaceChildren("Product changed \xB7 re-analyse");
      }
    };
    variationObserver = new MutationObserver(check);
    targets.forEach(
      (target) => variationObserver.observe(target, {
        attributes: true,
        childList: true,
        subtree: true,
        characterData: true
      })
    );
    window.addEventListener("popstate", check, { once: true });
  }
  async function runAnalysis() {
    try {
      const host = location.hostname;
      const amazonSupported = /(^|\.)(amazon\.com|amazon\.co\.uk)$/i.test(host);
      const demoMode = Boolean(document.querySelector('[data-ecomind-demo-product="true"]'));
      if (!amazonSupported && !demoMode) {
        notifyPopup("unsupported", "This marketplace is not supported in the current real-page pilot. Use Amazon US/UK clothing pages or the clearly labelled Threadly Demo Mode.");
        return;
      }
      notifyPopup(
        "analysing",
        "Reading product evidence from this active page locally."
      );
      const parsed = parseProductPage(document, location.href);
      currentProduct = parsed.product;
      currentDiagnostics = parsed.diagnostics;
      const state = await readExtensionState();
      const savedCorrections = state.manualCorrections[productKey(currentProduct)];
      if (savedCorrections)
        currentProduct = applyManualCorrections(currentProduct, savedCorrections);
      currentAnalysis = displayAnalysis(currentProduct);
      recordAnalysis(state, currentProduct);
      await writeExtensionState(state);
      renderExtension(currentProduct, currentAnalysis, state, currentDiagnostics);
      installVariationWatch(currentProduct);
      if (!currentProduct.isProduct)
        notifyPopup(
          "unsupported",
          "EcoMind could not confirm a product page. Open the koala to enter product information manually.",
          currentAnalysis
        );
      else if (!currentProduct.isClothing)
        notifyPopup(
          "unsupported-category",
          "Product detected, but EcoMind currently scores clothing and textile products. Manual evidence is available.",
          currentAnalysis
        );
      else if (!currentAnalysis.canScore)
        notifyPopup(
          "missing-data",
          "Product detected, but material composition is not disclosed. Manual confirmation is available.",
          currentAnalysis
        );
      else if (currentAnalysis.confidence === "Low")
        notifyPopup(
          "low-confidence",
          `${currentProduct.retailer} product analysed with low confidence. Review missing evidence or add a correction.`,
          currentAnalysis
        );
      else if (currentAnalysis.factors.some((item) => item.result.status === "unknown"))
        notifyPopup(
          "missing-data",
          `${currentProduct.retailer} product analysed provisionally. Missing factors remain unknown.`,
          currentAnalysis
        );
      else
        notifyPopup(
          "success",
          `${currentProduct.retailer} clothing product analysed locally. Open the koala for evidence.`,
          currentAnalysis
        );
    } catch (error) {
      notifyPopup(
        "error",
        `${error instanceof Error ? error.message : "Local parser failed."} Try again or use manual entry.`
      );
    }
  }
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      if (message.type === "ECOMIND_GET_STATUS")
        sendResponse({
          type: "ECOMIND_STATUS_UPDATE",
          state: analysisState,
          detail: analysisDetail,
          ...currentAnalysis ? {
            score: currentAnalysis.score,
            range: currentAnalysis.range,
            grade: currentAnalysis.grade,
            confidence: currentAnalysis.confidence,
            provisional: currentAnalysis.provisional,
            hasSufficientEvidence: currentAnalysis.hasSufficientEvidence
          } : {}
        });
      if (message.type === "ECOMIND_STATUS_UPDATE" && (message.detail === "open-widget" || message.detail === "show-widget")) {
        const host = document.getElementById(ROOT_ID);
        if (host) host.hidden = false;
        shadow?.querySelector(".layer")?.classList.add("open");
        document.body.inert = true;
        shadow?.querySelector(".close")?.focus();
      }
      if (message.type === "ECOMIND_STATUS_UPDATE" && message.detail === "disable-widget") {
        const host = document.getElementById(ROOT_ID);
        document.body.inert = false;
        if (host) host.hidden = true;
      }
      if (message.type === "ECOMIND_STATUS_UPDATE" && message.detail === "preferences-changed" && currentProduct && currentAnalysis && currentDiagnostics) {
        void readExtensionState().then((state) => renderExtension(currentProduct, currentAnalysis, state, currentDiagnostics));
      }
      if (message.type === "ECOMIND_STATUS_UPDATE" && message.detail === "rerun-analysis") {
        variationObserver?.disconnect();
        void runAnalysis();
        sendResponse({
          type: "ECOMIND_STATUS_UPDATE",
          state: "analysing",
          detail: "Analysis restarted from the current DOM."
        });
      }
    }
  );
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]?.newValue)
      shadow?.querySelector(".widget .copy small")?.setAttribute("data-storage-updated", "true");
  });
  var extensionWindow = window;
  if (!extensionWindow.__ECOMIND_CONTENT_LOADED__) {
    extensionWindow.__ECOMIND_CONTENT_LOADED__ = true;
    void runAnalysis();
  }
})();
