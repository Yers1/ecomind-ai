"use strict";
(() => {
  // extension/src/shared.ts
  var STORAGE_KEY = "ecomindExtensionState";
  var DEFAULT_EXTENSION_STATE = {
    points: 35,
    wishlist: [],
    completedActions: [],
    activities: [
      {
        id: "extension-welcome",
        title: "Extension profile started",
        detail: "Starter points added for the EcoMind extension demo.",
        points: 35,
        date: "Today"
      }
    ],
    preferences: {
      showWidgetAfterAnalysis: true
    }
  };
  function readExtensionState() {
    return new Promise((resolve) => {
      chrome.storage.local.get(STORAGE_KEY, (result) => {
        const saved = result[STORAGE_KEY];
        resolve({
          ...DEFAULT_EXTENSION_STATE,
          ...saved,
          wishlist: Array.isArray(saved?.wishlist) ? saved.wishlist : [],
          completedActions: Array.isArray(saved?.completedActions) ? saved.completedActions : [],
          activities: Array.isArray(saved?.activities) ? saved.activities : DEFAULT_EXTENSION_STATE.activities,
          preferences: {
            ...DEFAULT_EXTENSION_STATE.preferences,
            ...saved?.preferences ?? {}
          }
        });
      });
    });
  }

  // extension/src/popup.ts
  var statusCard = document.querySelector(".status-card");
  var statusText = document.querySelector("#statusText");
  var statusDetail = document.querySelector("#statusDetail");
  var analyseButton = document.querySelector("#analyseButton");
  var dashboardButton = document.querySelector("#dashboardButton");
  var pointsValue = document.querySelector("#pointsValue");
  var activeTab;
  var currentState = "checking";
  var labels = {
    checking: { title: "Checking page...", detail: "EcoMind has not read this page." },
    ready: { title: "Ready to analyse", detail: "A supported EcoMind demo page is open." },
    analysing: { title: "Analysing locally", detail: "Reading the visible demo product information." },
    success: { title: "Analysis complete", detail: "Open the injected koala to see the Green Score." },
    "missing-data": { title: "Missing product data", detail: "The score shows uncertainty and undisclosed fields." },
    "low-confidence": { title: "Low confidence", detail: "Important information is missing from this demo listing." },
    unsupported: { title: "Unsupported page", detail: "Open an EcoMind Amazon-style demo product page." },
    error: { title: "Analysis error", detail: "EcoMind could not analyse this page. Try again." }
  };
  function setStatus(state, detail) {
    currentState = state;
    statusCard.dataset.state = state;
    statusText.textContent = labels[state].title;
    statusDetail.textContent = detail ?? labels[state].detail;
    analyseButton.disabled = !["ready", "error", "missing-data", "low-confidence", "success"].includes(state);
    analyseButton.textContent = state === "success" || state === "missing-data" || state === "low-confidence" ? "Show EcoMind widget" : state === "error" ? "Try analysis again" : "Analyse this product";
  }
  function isDemoUrl(url) {
    if (!url) return false;
    try {
      const parsed = new URL(url);
      return parsed.protocol.startsWith("http") && (parsed.hostname === "127.0.0.1" || parsed.hostname === "localhost" || parsed.hostname === "ecomind-ai-two.vercel.app" || parsed.hostname.endsWith("-yers1ts-projects.vercel.app"));
    } catch {
      return false;
    }
  }
  function refreshPoints(state) {
    pointsValue.textContent = String(state.points);
  }
  function getActiveTab() {
    return new Promise((resolve) => chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs[0])));
  }
  function sendToTab(message) {
    return new Promise((resolve) => {
      if (!activeTab?.id) return resolve(void 0);
      chrome.tabs.sendMessage(activeTab.id, message, (response) => {
        if (chrome.runtime.lastError) resolve(void 0);
        else resolve(response);
      });
    });
  }
  async function initialise() {
    refreshPoints(await readExtensionState());
    activeTab = await getActiveTab();
    dashboardButton.disabled = !isDemoUrl(activeTab?.url);
    if (!isDemoUrl(activeTab?.url)) return setStatus("unsupported");
    const existing = await sendToTab({ type: "ECOMIND_GET_STATUS" });
    setStatus(existing?.state ?? "ready", existing?.detail);
  }
  analyseButton.addEventListener("click", async () => {
    if (!activeTab?.id || !isDemoUrl(activeTab.url)) return setStatus("unsupported");
    if (["success", "missing-data", "low-confidence"].includes(currentState)) {
      await sendToTab({ type: "ECOMIND_STATUS_UPDATE", state: currentState, detail: "open-widget" });
      window.close();
      return;
    }
    setStatus("analysing");
    const retryResponse = await sendToTab({ type: "ECOMIND_STATUS_UPDATE", state: "analysing", detail: "rerun-analysis" });
    if (retryResponse) return;
    chrome.scripting.executeScript({ target: { tabId: activeTab.id }, files: ["content.js"] }, () => {
      if (chrome.runtime.lastError) setStatus("error", chrome.runtime.lastError.message);
    });
  });
  dashboardButton.addEventListener("click", () => {
    if (!activeTab?.id || !activeTab.url || !isDemoUrl(activeTab.url)) return;
    const dashboardUrl = new URL(activeTab.url);
    dashboardUrl.hash = "/dashboard";
    chrome.tabs.update(activeTab.id, { url: dashboardUrl.toString() });
    window.close();
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "ECOMIND_STATUS_UPDATE" && message.state) setStatus(message.state, message.detail);
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]?.newValue) refreshPoints(changes[STORAGE_KEY].newValue);
  });
  void initialise();
})();
