"use strict";
(() => {
  // extension/src/shared.ts
  var STORAGE_KEY = "ecomindExtensionState";
  var DEFAULT_EXTENSION_STATE = {
    points: 35,
    wishlist: [],
    completedActions: [],
    activities: [
      {
        id: "extension-welcome",
        title: "Extension profile started",
        detail: "Starter points added for the EcoMind extension demo.",
        points: 35,
        date: "Today"
      }
    ],
    preferences: {
      showWidgetAfterAnalysis: true
    }
  };
  function readExtensionState() {
    return new Promise((resolve) => {
      chrome.storage.local.get(STORAGE_KEY, (result) => {
        const saved = result[STORAGE_KEY];
        resolve({
          ...DEFAULT_EXTENSION_STATE,
          ...saved,
          wishlist: Array.isArray(saved?.wishlist) ? saved.wishlist : [],
          completedActions: Array.isArray(saved?.completedActions) ? saved.completedActions : [],
          activities: Array.isArray(saved?.activities) ? saved.activities : DEFAULT_EXTENSION_STATE.activities,
          preferences: {
            ...DEFAULT_EXTENSION_STATE.preferences,
            ...saved?.preferences ?? {}
          }
        });
      });
    });
  }
  function writeExtensionState(state) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.set({ [STORAGE_KEY]: state }, () => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve();
      });
    });
  }
  function ensureExtensionState() {
    return readExtensionState().then(async (state) => {
      await writeExtensionState(state);
      return state;
    });
  }

  // extension/src/background.ts
  chrome.runtime.onInstalled.addListener(() => {
    void ensureExtensionState();
  });
  chrome.runtime.onStartup.addListener(() => {
    void ensureExtensionState();
  });
})();
